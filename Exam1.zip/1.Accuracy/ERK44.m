function [err,gamma_average]=ERK44(tau)
warning off;
N=200;  left=0;  right=2;  h=(right-left)/N;  xmesh=left+h:h:right;  xmesh=xmesh';
d=size(xmesh,1);  
L=-( (-13/8)*diag(ones(1,d-1), 1) ...
    +        diag(ones(1,d-2), 2) ...
    + (-1/8)*diag(ones(1,d-3), 3) ...
    +  (1/8)*diag(ones(1,3), d-3) ...
    +   (-1)*diag(ones(1,2), d-2) ...
    + (13/8)*diag(ones(1,1), d-1) ...
    + (13/8)*diag(ones(1,d-1), -1) ...
    +   (-1)*diag(ones(1,d-2), -2) ...
    +  (1/8)*diag(ones(1,d-3), -3) ...
    + (-1/8)*diag(ones(1,3), 3-d) ...
    +        diag(ones(1,2), 2-d) ...
    +(-13/8)*diag(ones(1,1), 1-d))/h/h/h; 
Zn=cos(pi*xmesh);

c2=0.5;  c3=0.5;  c4=1;  
A21=c2*phipade(c2*tau*L,1);  
A32=phipade(c3*tau*L,2);  A31=c3*phipade(c3*tau*L,1)-A32;
A43=2*phipade(c4*tau*L,2);  A41=phipade(c4*tau*L,1)-A43;
P1=phipade(tau*L,1);  P2=phipade(tau*L,2);  P3=phipade(tau*L,3); 
B1=P1-3*P2+4*P3;  B2=2*P2-4*P3;  B3=B2;  B4=-P2+4*P3;

tmesh=[];  GAMMA=[];  Energy=[];
  
T=1;  tn=0; 
while (tn<(T-tau))
    LZn=L*Zn;
    %%%% Zn1
    Zn1=Zn;
    %%%% Zn2
    Fn1=compute_nonlinear(Zn1,d,h)+LZn;  Zn2=Zn+tau*A21*Fn1;
    %%%% Zn3
    Fn2=compute_nonlinear(Zn2,d,h)+LZn;  Zn3=Zn+tau*A31*Fn1+tau*A32*Fn2;
    %%%% Zn4
    Fn3=compute_nonlinear(Zn3,d,h)+LZn;  Zn4=Zn+tau*A41*Fn1+tau*A43*Fn3;
    %%%% Znew
    Fn4=compute_nonlinear(Zn4,d,h)+LZn;  Znew=Zn+tau*B1*Fn1+tau*B2*Fn2+tau*B3*Fn3+tau*B4*Fn4; 
    energy_old=h*real(Zn'*Zn);  Energy=[Energy energy_old];  tmesh=[tmesh tn]; 
    Update=Znew-Zn;
    if ( (sum(abs(Update)))==0 )
        gamma=1;
    else
        gamma=(-2*real(Zn'*Update))/(Update'*Update);
        fprintf('t=%d, distance=%d',tn,abs(gamma-1));
    end
    Zn_save=Zn;  tn_save=tn;
    GAMMA=[GAMMA gamma];  Zn=Zn+gamma*Update;  tn=tn+gamma*tau
end
energy_old=h*real(Zn'*Zn);  Energy=[Energy energy_old];  tmesh=[tmesh tn]; 

if ( (T-tn)<=0 )
    GAMMA=GAMMA(1:end-1);  Energy=Energy(1:end-1);  tmesh=tmesh(1:end-1);
    Zn=Zn_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
A21=c2*phipade(c2*tau*L,1);  
A32=phipade(c3*tau*L,2);  A31=c3*phipade(c3*tau*L,1)-A32;
A43=2*phipade(c4*tau*L,2);  A41=phipade(c4*tau*L,1)-A43;
P1=phipade(tau*L,1);  P2=phipade(tau*L,2);  P3=phipade(tau*L,3); 
B1=P1-3*P2+4*P3;  B2=2*P2-4*P3;  B3=B2;  B4=-P2+4*P3;
LZn=L*Zn;
%%%% Zn1
Zn1=Zn;
%%%% Zn2
Fn1=compute_nonlinear(Zn1,d,h)+LZn;  Zn2=Zn+tau*A21*Fn1;
%%%% Zn3
Fn2=compute_nonlinear(Zn2,d,h)+LZn;  Zn3=Zn+tau*A31*Fn1+tau*A32*Fn2;
%%%% Zn4
Fn3=compute_nonlinear(Zn3,d,h)+LZn;  Zn4=Zn+tau*A41*Fn1+tau*A43*Fn3;
%%%% Znew
Fn4=compute_nonlinear(Zn4,d,h)+LZn;  Zn=Zn+tau*B1*Fn1+tau*B2*Fn2+tau*B3*Fn3+tau*B4*Fn4;  tn=tn+tau;
    
load reference.mat;  
err=max(abs(Zn-Zn_Gauss4_100000));
gamma_average=mean(abs(GAMMA-1));