function [err,gamma_average]=ERK22(tau)
warning off;
N=200;  left=0;  right=2;  h=(right-left)/N;  xmesh=left+h:h:right;  xmesh=xmesh';
d=size(xmesh,1);  
L=-( (-13/8)*diag(ones(1,d-1), 1) ...
    +        diag(ones(1,d-2), 2) ...
    + (-1/8)*diag(ones(1,d-3), 3) ...
    +  (1/8)*diag(ones(1,3), d-3) ...
    +   (-1)*diag(ones(1,2), d-2) ...
    + (13/8)*diag(ones(1,1), d-1) ...
    + (13/8)*diag(ones(1,d-1), -1) ...
    +   (-1)*diag(ones(1,d-2), -2) ...
    +  (1/8)*diag(ones(1,d-3), -3) ...
    + (-1/8)*diag(ones(1,3), 3-d) ...
    +        diag(ones(1,2), 2-d) ...
    +(-13/8)*diag(ones(1,1), 1-d))/h/h/h; 
Zn=cos(pi*xmesh);

c2=0.5;  A21=c2*phipade(c2*tau*L,1);  
b2=1;  B2=(1/c2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B2;
 
tmesh=[];  GAMMA=[];  Energy=[];

T=1;  tn=0; 
while (tn<(T-tau))
    LZn=L*Zn;
    %%%% Zn1
    Zn1=Zn;
    %%%% Zn2
    Fn1=compute_nonlinear(Zn1,d,h)+LZn;  Zn2=Zn+tau*A21*Fn1;
    %%%% Znew
    Fn2=compute_nonlinear(Zn2,d,h)+LZn;  Znew=Zn+tau*B1*Fn1+tau*B2*Fn2; 
    energy_old=h*real(Zn'*Zn);  Energy=[Energy energy_old];  tmesh=[tmesh tn]; 
    Update=Znew-Zn;
    if ( (sum(abs(Update)))==0 )
        gamma=1;
    else
        gamma=(-2*real(Zn'*Update))/(Update'*Update);
        fprintf('t=%d, distance=%d\n',tn,abs(gamma-1));
    end
    Zn_save=Zn;  tn_save=tn;
    GAMMA=[GAMMA gamma];  Zn=Zn+gamma*Update;  tn=tn+gamma*tau
end
energy_old=h*real(Zn'*Zn);  Energy=[Energy energy_old];  tmesh=[tmesh tn]; 

if ( (T-tn)<=0 )
    GAMMA=GAMMA(1:end-1);  Energy=Energy(1:end-1);  tmesh=tmesh(1:end-1);
    Zn=Zn_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
A21=c2*phipade(c2*tau*L,1);  
B2=(1/c2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B2;
LZn=L*Zn;
%%%% Zn1
Zn1=Zn;
%%%% Zn2
Fn1=compute_nonlinear(Zn1,d,h)+LZn;  Zn2=Zn+tau*A21*Fn1;
%%%% Zn
Fn2=compute_nonlinear(Zn2,d,h)+LZn;  Zn=Zn+tau*B1*Fn1+tau*B2*Fn2;  tn=tn+tau;

load reference.mat;  
err=max(abs(Zn-Zn_Gauss4_100000));
gamma_average=mean(abs(GAMMA-1));
