function F=compute_nonlinear(Zn,d,h)

P1=[Zn(2:d,:);Zn(1,:)];  P2=[Zn(d,:);Zn(1:d-1,:)];
P3=[Zn(3:d,:);Zn(1:2,:)];  P4=[Zn(d-1:d,:);Zn(1:d-2,:)];
F=(2/9/h)*(P1+Zn+P2).*(P1-P2)-(1/36/h)*(P3+Zn+P4).*(P3-P4);
F=-F;


