function [Xn,t]=Solver(tau)
T=1;
%%%%%%%%%%%%%%%% 2-stages %%%%%%%%%%%%%%%%
% Gauss
% A=[1/4 1/4-sqrt(3)/6; 1/4+sqrt(3)/6 1/4];
% b=[1/2 1/2];
% c=[1/2-sqrt(3)/6; 1/2+sqrt(3)/6];
%%%%%%%%%%%%%%%% 3-stages %%%%%%%%%%%%%%%%
% Gauss
% A=[5/36 2/9-sqrt(15)/15 5/36-sqrt(15)/30; ...
%    5/36+sqrt(15)/24 2/9 5/36-sqrt(15)/24; ...
%    5/36+sqrt(15)/30 2/9+sqrt(15)/15 5/36];
% b=[5/18 4/9 5/18];
% c=[1/2-sqrt(15)/10; 1/2; 1/2+sqrt(15)/10];
%%%%%%%%%%%%%%%% 4-stages %%%%%%%%%%%%%%%%
% Gauss
w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

N=200;  left=0;  right=2;  h=(right-left)/N;  xmesh=left+h:h:right;  xmesh=xmesh';
d=size(xmesh,1);  
L=-( (-13/8)*diag(ones(1,d-1), 1) ...
    +        diag(ones(1,d-2), 2) ...
    + (-1/8)*diag(ones(1,d-3), 3) ...
    +  (1/8)*diag(ones(1,3), d-3) ...
    +   (-1)*diag(ones(1,2), d-2) ...
    + (13/8)*diag(ones(1,1), d-1) ...
    + (13/8)*diag(ones(1,d-1), -1) ...
    +   (-1)*diag(ones(1,d-2), -2) ...
    +  (1/8)*diag(ones(1,d-3), -3) ...
    + (-1/8)*diag(ones(1,3), 3-d) ...
    +        diag(ones(1,2), 2-d) ...
    +(-13/8)*diag(ones(1,1), 1-d))/h/h/h; 
s=size(A,1);  es=ones(s,1);  Id=speye(d);
AI=kron(A,Id);  bI=kron(b,Id);  bL=kron(b,L);  Matrix=(eye(d*s)-tau*kron(A,L))^(-1);
t=0;  Xn=cos(pi*xmesh);  

for k=1:round(T/tau)
    Iter_err=1;  ccout=0;  Xmid=kron(es,Xn);
    while (Iter_err > 10^(-14) && ccout < 100)
        Xmid_c=reshape(Xmid,d,s);  Fmid_c=compute_nonlinear(Xmid_c,d,h);
        F=kron(es,Xn)+tau*AI*Fmid_c(:); 
        Xmid_save=Xmid;  Xmid=Matrix*F;
        Iter_err=max(abs(Xmid-Xmid_save));
        ccout=ccout+1;
    end
    Xmid_c=reshape(Xmid,d,s);  Fmid_c=compute_nonlinear(Xmid_c,d,h);
    Update=tau*bL*Xmid+tau*bI*Fmid_c(:);
    Xn=Xn+Update;
    t=t+tau; 
    k
end