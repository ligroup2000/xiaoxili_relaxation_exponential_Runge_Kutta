stepsize=[1/256 1/512 1/1024 1/2048 1/4096]; 

Gamma_average_save=[];  Err=[]; 
for k=1:size(stepsize,2)
    tau=stepsize(1,k);
    [err,gamma_average]=ERK44(tau); 
    Gamma_average_save=[Gamma_average_save gamma_average]; 
    Err=[Err err];
end


Err 
Err_order=log(Err(1:end-1)./Err(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
Gamma_average_save
Gamma_average_order=log(Gamma_average_save(1:end-1)./Gamma_average_save(2:end))./log(stepsize(1:end-1)./stepsize(2:end))