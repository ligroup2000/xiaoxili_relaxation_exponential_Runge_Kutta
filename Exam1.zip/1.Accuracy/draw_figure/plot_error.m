%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.24;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.41;  % ��ͼ��ͼƬ�ҷ��ļ��


%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

load ERK22.mat
stepsize2=stepsize;  Err2=Err;
load ERK33.mat
stepsize3=stepsize;  Err3=Err;
load ERK44.mat
stepsize4=stepsize;  Err4=Err;


loglog(stepsize2,Err2,'-ro','LineWidth',2,'MarkerSize',10,'MarkerFaceColor','r');  hold on;
loglog(stepsize3,Err3,'-gd','LineWidth',2,'MarkerSize',10,'MarkerFaceColor','g');
loglog(stepsize4,Err4,'-bs','LineWidth',2,'MarkerSize',10,'MarkerFaceColor','b');
loglog([stepsize2(end) stepsize2(end-1)],[3*Err2(end) 3*4*Err2(end)],':r','LineWidth',2,'MarkerSize',10);
loglog([stepsize3(end) stepsize3(end-1)],[3*Err3(end) 3*8*Err3(end)],':g','LineWidth',2,'MarkerSize',10);
loglog([stepsize4(end) stepsize4(end-1)],[3*Err4(end) 3*16*Err4(end)],':b','LineWidth',2,'MarkerSize',10);
box on;  set(gca,'linewidth',2,'FontSize',30)
set(gca,'XLim',[0.0002 0.005])
% set(gca,'xTick',[10^(-2), 10^(-1)]);  set(gca,'XTickLabel',{'10^{-2}','10^{-1}'});
set(gca,'YLim',[10^(-12) 10^(-3)])
% set(gca,'yTick',[10^(-10),10^(-6),10^(-3)]);  set(gca,'YTickLabel',{'10^{-10}','10^{-6}','10^{-3}'});
xlabel('\tau','FontSize',30)
ylabel('$L^\infty$-$error$','interpreter','latex','FontSize',30)
legend('RERK(2,2)','RERK(3,3)','RERK(4,4)','slope=2','slope=3','slope=4')
set(legend,'interpreter','latex','location','Southeast','FontSize',24) 