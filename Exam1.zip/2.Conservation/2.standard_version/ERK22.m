function [CPUtime,tmesh,Energy]=ERK22(tau)
warning off;  tic;
N=200;  left=0;  right=2;  h=(right-left)/N;  xmesh=left+h:h:right;  xmesh=xmesh';
d=size(xmesh,1);  
L=-( (-13/8)*diag(ones(1,d-1), 1) ...
    +        diag(ones(1,d-2), 2) ...
    + (-1/8)*diag(ones(1,d-3), 3) ...
    +  (1/8)*diag(ones(1,3), d-3) ...
    +   (-1)*diag(ones(1,2), d-2) ...
    + (13/8)*diag(ones(1,1), d-1) ...
    + (13/8)*diag(ones(1,d-1), -1) ...
    +   (-1)*diag(ones(1,d-2), -2) ...
    +  (1/8)*diag(ones(1,d-3), -3) ...
    + (-1/8)*diag(ones(1,3), 3-d) ...
    +        diag(ones(1,2), 2-d) ...
    +(-13/8)*diag(ones(1,1), 1-d))/h/h/h;  L=0.022*0.022*L;
Zn=cos(pi*xmesh);


c2=0.5;  A21=c2*phipade(c2*tau*L,1);  
B2=(1/c2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B2;
 
tmesh=[];  Energy=[];

T=200;  tn=0; 
while (tn<(T-tau))
    LZn=L*Zn;
    %%%% Zn1
    Zn1=Zn;
    %%%% Zn2
    Fn1=compute_nonlinear(Zn1,d,h)+LZn;  Zn2=Zn+tau*A21*Fn1;
    %%%% Znew
    Fn2=compute_nonlinear(Zn2,d,h)+LZn;  Znew=Zn+tau*B1*Fn1+tau*B2*Fn2; 
    energy_old=h*real(Zn'*Zn);  Energy=[Energy energy_old];  tmesh=[tmesh tn];
    Update=Znew-Zn;
    Zn=Zn+Update;  tn=tn+tau
end
energy_old=h*real(Zn'*Zn);  Energy=[Energy energy_old];  tmesh=[tmesh tn];

toc;  CPUtime=toc;
plot(tmesh,abs(Energy-Energy(1))/abs(Energy(1)));
save('ERK22.mat','CPUtime','tmesh','Energy');