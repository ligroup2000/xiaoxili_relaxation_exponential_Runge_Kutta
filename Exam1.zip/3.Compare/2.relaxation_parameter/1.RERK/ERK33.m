function [tmesh,GAMMA]=ERK33(tau)
warning off;
N=200;  left=0;  right=2;  h=(right-left)/N;  xmesh=left+h:h:right;  xmesh=xmesh';
d=size(xmesh,1);  
L=-( (-13/8)*diag(ones(1,d-1), 1) ...
    +        diag(ones(1,d-2), 2) ...
    + (-1/8)*diag(ones(1,d-3), 3) ...
    +  (1/8)*diag(ones(1,3), d-3) ...
    +   (-1)*diag(ones(1,2), d-2) ...
    + (13/8)*diag(ones(1,1), d-1) ...
    + (13/8)*diag(ones(1,d-1), -1) ...
    +   (-1)*diag(ones(1,d-2), -2) ...
    +  (1/8)*diag(ones(1,d-3), -3) ...
    + (-1/8)*diag(ones(1,3), 3-d) ...
    +        diag(ones(1,2), 2-d) ...
    +(-13/8)*diag(ones(1,1), 1-d))/h/h/h; 
Zn=cos(pi*xmesh);

c2=0.5;  c3=2/3;  
A21=c2*phipade(c2*tau*L,1);  
A32=(8/9)*phipade(c3*tau*L,2);  A31=c3*phipade(c3*tau*L,1)-A32; 
B3=(3/2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B3;

tmesh=[];  GAMMA=[];
 
T=25;  tn=0; 
while (tn<(T-tau))
    LZn=L*Zn;
    %%%% Zn1
    Zn1=Zn;
    %%%% Zn2
    Fn1=compute_nonlinear(Zn1,d,h)+LZn;  Zn2=Zn+tau*A21*Fn1;
    %%%% Zn3
    Fn2=compute_nonlinear(Zn2,d,h)+LZn;  Zn3=Zn+tau*A31*Fn1+tau*A32*Fn2;
    %%%% Znew
    Fn3=compute_nonlinear(Zn3,d,h)+LZn;  Znew=Zn+tau*B1*Fn1+tau*B3*Fn3; 
    tmesh=[tmesh tn]; 
    Update=Znew-Zn;
    if ( (sum(abs(Update)))==0 )
        gamma=1;
    else
        gamma=(-2*real(Zn'*Update))/(Update'*Update);
        fprintf('t=%d, distance=%d\n',tn,abs(gamma-1));
    end
    GAMMA=[GAMMA gamma];  Zn=Zn+gamma*Update;  tn=tn+gamma*tau
end

save('ERK33_2.mat','GAMMA','tmesh');