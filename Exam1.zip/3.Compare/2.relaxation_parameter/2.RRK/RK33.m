function [tmesh,GAMMA]=RK33(tau)
N=200;  left=0;  right=2;  h=(right-left)/N;  xmesh=left+h:h:right;  xmesh=xmesh';
d=size(xmesh,1);  
L=-( (-13/8)*diag(ones(1,d-1), 1) ...
    +        diag(ones(1,d-2), 2) ...
    + (-1/8)*diag(ones(1,d-3), 3) ...
    +  (1/8)*diag(ones(1,3), d-3) ...
    +   (-1)*diag(ones(1,2), d-2) ...
    + (13/8)*diag(ones(1,1), d-1) ...
    + (13/8)*diag(ones(1,d-1), -1) ...
    +   (-1)*diag(ones(1,d-2), -2) ...
    +  (1/8)*diag(ones(1,d-3), -3) ...
    + (-1/8)*diag(ones(1,3), 3-d) ...
    +        diag(ones(1,2), 2-d) ...
    +(-13/8)*diag(ones(1,1), 1-d))/h/h/h; 
Zn=cos(pi*xmesh);
c2=0.5;  c3=2/3;  a21=1/2;  a31=2/9;  a32=4/9;  b1=1/4;  b3=3/4;

tmesh=[];  GAMMA=[];
 
T=3;  tn=0; 
for k=1:1000
    %%%% Zn1
    Zn1=Zn;
    %%%% Zn2
    Fn1=compute_nonlinear(Zn1,d,h)+L*Zn1;  Zn2=Zn+tau*a21*Fn1;
    %%%% Zn3
    Fn2=compute_nonlinear(Zn2,d,h)+L*Zn2;  Zn3=Zn+tau*a31*Fn1+tau*a32*Fn2;
    %%%% Znew
    Fn3=compute_nonlinear(Zn3,d,h)+L*Zn3;  Znew=Zn+tau*b1*Fn1+tau*b3*Fn3; 
    tmesh=[tmesh tn]; 
    Update=Znew-Zn;
    if ( (sum(abs(Update)))==0 )
        gamma=1;
    else
        gamma=(-2*real(Zn'*Update))/(Update'*Update);
        fprintf('t=%d, distance=%d\n',tn,abs(gamma-1));
    end
    GAMMA=[GAMMA gamma];  Zn=Zn+gamma*Update;  tn=tn+gamma*tau
end

save('RK33_100000.mat','tmesh','GAMMA')