% stepsize=[1/1024 1/2048 1/4096 1/4096/2 1/4096/4];  % ERK22
stepsize=[1/256 1/512 1/1024 1/2048 1/4096]; % ERK44

ERR=[];  TIME=[];  Energy_Dis=[];
for k=1:size(stepsize,2)
    tau=stepsize(1,k);
    [CPUtime,err,energy_err]=ERK44(tau); 
    TIME=[TIME CPUtime];
    ERR=[ERR err]; 
    Energy_Dis=[Energy_Dis energy_err];
end

Err_Order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end))

save('ERK44.mat','TIME','ERR','Energy_Dis');
