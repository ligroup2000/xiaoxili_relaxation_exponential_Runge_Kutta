%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 2;     % ��ͼ����
TightPlot.RowNumber = 3;    % ��ͼ����
TightPlot.GapW = 0.08;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.14;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.12;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.02;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.08;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.16;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

load RERK22.mat;
% 1 104 206
axes(p(1));
k=1;  Z_temp=Zn_save(:,k);
plot([-40;xmesh],[Z_temp(end);Z_temp],'b','linewidth',2)
box on;  set(gca,'linewidth',2,'FontSize',24);
set(gca,'ylim',[-0.2,1.2])
set(gca,'xlim',[-40,40])
xlabel('$x$','interpreter','latex','FontSize',30)
ylabel('$u^n_{\gamma_{n-1}}$','interpreter','latex','FontSize',30)
legend('$t=0$');  
set(legend,'interpreter','latex','location','northeast','FontSize',20); 

axes(p(2));
k=104;  Z_temp=Zn_save(:,k);
plot([-40;xmesh],[Z_temp(end);Z_temp],'b','linewidth',2)
box on;  set(gca,'linewidth',2,'FontSize',24);
set(gca,'ylim',[-0.2,1.2])
set(gca,'xlim',[-40,40])
xlabel('$x$','interpreter','latex','FontSize',30)
ylabel('$u^n_{\gamma_{n-1}}$','interpreter','latex','FontSize',30)
legend('$t=50.23$');  
set(legend,'interpreter','latex','location','northwest','FontSize',20); 

axes(p(3));
k=206;  Z_temp=Zn_save(:,k);
plot([-40;xmesh],[Z_temp(end);Z_temp],'b','linewidth',2)
box on;  set(gca,'linewidth',2,'FontSize',24);
set(gca,'ylim',[-0.2,1.2])
set(gca,'xlim',[-40,40])
xlabel('$x$','interpreter','latex','FontSize',30)
ylabel('$u^n_{\gamma_{n-1}}$','interpreter','latex','FontSize',30)
legend('$t=99.98$');  
set(legend,'interpreter','latex','location','northwest','FontSize',20); 

load RERK33.mat;

axes(p(4));
k=1;  Z_temp=Zn_save(:,k);
plot([-40;xmesh],[Z_temp(end);Z_temp],'b','linewidth',2)
box on;  set(gca,'linewidth',2,'FontSize',24);
set(gca,'ylim',[-0.2,1.2])
set(gca,'xlim',[-40,40])
xlabel('$x$','interpreter','latex','FontSize',30)
ylabel('$u^n_{\gamma_{n-1}}$','interpreter','latex','FontSize',30)
legend('$t=0$');  
set(legend,'interpreter','latex','location','northeast','FontSize',20); 

axes(p(5));
k=200;  Z_temp=Zn_save(:,k);
plot([-40;xmesh],[Z_temp(end);Z_temp],'b','linewidth',2)
box on;  set(gca,'linewidth',2,'FontSize',24);
set(gca,'ylim',[-0.2,1.2])
set(gca,'xlim',[-40,40])
xlabel('$x$','interpreter','latex','FontSize',30)
ylabel('$u^n_{\gamma_{n-1}}$','interpreter','latex','FontSize',30)
legend('$t=49.90$');  
set(legend,'interpreter','latex','location','northeast','FontSize',20); 

axes(p(6));
k=400;  Z_temp=Zn_save(:,k);
plot([-40;xmesh],[Z_temp(end);Z_temp],'b','linewidth',2)
box on;  set(gca,'linewidth',2,'FontSize',24);
set(gca,'ylim',[-0.2,1.2])
set(gca,'xlim',[-40,40])
xlabel('$x$','interpreter','latex','FontSize',30)
ylabel('$u^n_{\gamma_{n-1}}$','interpreter','latex','FontSize',30)
legend('$t=99.97$');  
set(legend,'interpreter','latex','location','northwest','FontSize',20); 