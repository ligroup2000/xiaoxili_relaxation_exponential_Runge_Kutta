%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.24;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.41;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);   
load('ERK22.mat');
tmesh_2=tmesh;  Energy_2=Energy;
load('ERK33.mat');
tmesh_3=tmesh;  Energy_3=Energy;  
load('ERK44.mat');
tmesh_4=tmesh;  Energy_4=Energy; 
load('RERK22.mat');
tmesh_r2=tmesh;  Energy_r2=Energy; 
load('RERK33.mat');
tmesh_r3=tmesh;  Energy_r3=Energy;
load('RERK44.mat');
tmesh_r4=tmesh;  Energy_r4=Energy;


axes(p(1));    % ��ȡ��ǰfigure����Ϣ
semilogy(tmesh_2,abs(Energy_2-Energy_2(1))/abs(Energy_2(1)),':r','LineWidth',2);  hold on;
semilogy(tmesh_r2(1:end-1),abs(Energy_r2(1:end-1)-Energy_r2(1))/abs(Energy_r2(1)),'r','LineWidth',2);
semilogy(tmesh_3,abs(Energy_3-Energy_3(1))/abs(Energy_3(1)),':g','LineWidth',2);
semilogy(tmesh_r3(1:end-1),abs(Energy_r3(1:end-1)-Energy_r3(1))/abs(Energy_r3(1)),'g','LineWidth',2);
semilogy(tmesh_4,abs(Energy_4-Energy_4(1))/abs(Energy_4(1)),':b','LineWidth',2);
semilogy(tmesh_r4(1:end-1),abs(Energy_r4(1:end-1)-Energy_r4(1))/abs(Energy_r4(1)),'b','LineWidth',2);
box on;  set(gca,'linewidth',2,'FontSize',30);
set(gca,'XLim',[0 200]);  
set(gca,'YLim',[10^(-16) 0.0001]);
set(gca,'yTick',[10^(-16),10^(-10),10^(-4)]);  set(gca,'YTickLabel',{'10^{-16}','10^{-10}','10^{-4}'});
xlabel('$t$','interpreter','latex','FontSize',30);
ylabel('$D^n$ or $D^n_\gamma$','interpreter','latex','FontSize',30);
legend('ERK(2,2): $\tau=1/20$, $t_c=95s$', ...
       'RERK(2,2): $\tau=1/2$, $t_c=10s$', ...
       'ERK(3,3): $\tau=1/20$, $t_c=140s$', ...
       'RERK(3,3): $\tau=1/2$, $t_c=16s$', ...
       'ERK(4,4): $\tau=1/20$, $t_c=238s$', ...
       'RERK(4,4): $\tau=1/2$, $t_c=26s$');  
set(legend,'interpreter','latex','Position',[0.294606912556977 0.263355356762802 0.286816698554134 0.280684395613175],'FontSize',20); 