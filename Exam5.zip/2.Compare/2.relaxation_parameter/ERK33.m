function [GAMMA,tmesh]=ERK33(tau)
nu=1;  T=2;  Le=-pi;  Re=pi;  N=64;  h=(Re-Le)/N;  area=(Re-Le)^3;
xmesh=Le:h:Re-h;  ymesh=xmesh;  zmesh=xmesh;  [X,Y,Z]=meshgrid(xmesh,ymesh,zmesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  z_freq=x_freq;  [X_freq,Y_freq,Z_freq]=meshgrid(x_freq,y_freq,z_freq);
Kx=1i*X_freq;  Ky=1i*Y_freq;  Kz=1i*Z_freq;  
Kxx=(-1)*X_freq.^2;  Kyy=(-1)*Y_freq.^2;  Kzz=(-1)*Z_freq.^2;  Kyyzz=Kyy+Kzz;  Kxxzz=Kxx+Kzz;  Kxxyy=Kxx+Kyy;   
Kxy=(-1)*X_freq.*Y_freq;  Kxz=(-1)*X_freq.*Z_freq;  Kzy=(-1)*Z_freq.*Y_freq; 
Kxxyyzz=Kxx+Kyy+Kzz;  Kxxyyzz_p=Kxxyyzz;  Kxxyyzz_p(1,1,1)=area; 
Kxxyyzz_f=spdiags(Kxxyyzz(:),0,N^3,N^3);
L=nu*Kxxyyzz_f;

c2=0.5;  c3=2/3;  
A21=c2*phipade(c2*tau*L,1);  
A32=(8/9)*phipade(c3*tau*L,2);  A31=c3*phipade(c3*tau*L,1)-A32;
b1=(1/4);  b3=(3/4);  
B3=(3/2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B3;
  
fftcoe=1/N/N/N;  ifftcoe=N*N*N;
U1=sin(X).*cos(Y).*cos(Z);  U1_t=fftcoe*fftn(U1); 
U2=-cos(X).*sin(Y).*cos(Z);  U2_t=fftcoe*fftn(U2);
U3=zeros(N,N,N);  U3_t=fftcoe*fftn(U3);  
U1_t_f=U1_t(:);  U2_t_f=U2_t(:);  U3_t_f=U3_t(:);  tn=0;  GAMMA=[];  tmesh=[];

while (tn<(T-tau))
    %%%% U1_n1_t_f  U2_n1_t_f  U3_n1_t_f
    LU1_t_f=L*U1_t_f;  LU2_t_f=L*U2_t_f;  LU3_t_f=L*U3_t_f;
    U1_n1_t_f=U1_t_f;  U2_n1_t_f=U2_t_f;  U3_n1_t_f=U3_t_f;
    %%%% U1_n2_t_f  U2_n2_t_f  U3_n2_t_f
    U1_mid_t=reshape(U1_n1_t_f,N,N,N);  U1_mid=real(ifftcoe*ifftn(U1_mid_t));  U1_mid_x=real(ifftcoe*ifftn(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifftn(Ky.*U1_mid_t));  U1_mid_z=real(ifftcoe*ifftn(Kz.*U1_mid_t));
    U2_mid_t=reshape(U2_n1_t_f,N,N,N);  U2_mid=real(ifftcoe*ifftn(U2_mid_t));  U2_mid_x=real(ifftcoe*ifftn(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifftn(Ky.*U2_mid_t));  U2_mid_z=real(ifftcoe*ifftn(Kz.*U2_mid_t));
    U3_mid_t=reshape(U3_n1_t_f,N,N,N);  U3_mid=real(ifftcoe*ifftn(U3_mid_t));  U3_mid_x=real(ifftcoe*ifftn(Kx.*U3_mid_t));  U3_mid_y=real(ifftcoe*ifftn(Ky.*U3_mid_t));  U3_mid_z=real(ifftcoe*ifftn(Kz.*U3_mid_t));
    G1_mid_t=fftcoe*fftn(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y+U3_mid.*U1_mid_z);  G1_mid_t(1,1,1)=0;  G1_mid_t=G1_mid_t./Kxxyyzz_p; 
    G2_mid_t=fftcoe*fftn(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y+U3_mid.*U2_mid_z);  G2_mid_t(1,1,1)=0;  G2_mid_t=G2_mid_t./Kxxyyzz_p; 
    G3_mid_t=fftcoe*fftn(U1_mid.*U3_mid_x+U2_mid.*U3_mid_y+U3_mid.*U3_mid_z);  G3_mid_t(1,1,1)=0;  G3_mid_t=G3_mid_t./Kxxyyzz_p;
    F1_mid_t=(-1)*Kyyzz.*G1_mid_t+Kxy.*G2_mid_t+Kxz.*G3_mid_t;  F1_mid_t_f=F1_mid_t(:);
    F2_mid_t=(-1)*Kxxzz.*G2_mid_t+Kxy.*G1_mid_t+Kzy.*G3_mid_t;  F2_mid_t_f=F2_mid_t(:);
    F3_mid_t=(-1)*Kxxyy.*G3_mid_t+Kxz.*G1_mid_t+Kzy.*G2_mid_t;  F3_mid_t_f=F3_mid_t(:);
    N1_n1_t_f=F1_mid_t_f+LU1_t_f;  N2_n1_t_f=F2_mid_t_f+LU2_t_f;  N3_n1_t_f=F3_mid_t_f+LU3_t_f; 
    U1_n2_t_f=U1_t_f+tau*A21*N1_n1_t_f;  U2_n2_t_f=U2_t_f+tau*A21*N2_n1_t_f;  U3_n2_t_f=U3_t_f+tau*A21*N3_n1_t_f;
    %%%% U1_n3_t_f  U2_n3_t_f  U3_n3_t_f
    U1_mid_t=reshape(U1_n2_t_f,N,N,N);  U1_mid=real(ifftcoe*ifftn(U1_mid_t));  U1_mid_x=real(ifftcoe*ifftn(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifftn(Ky.*U1_mid_t));  U1_mid_z=real(ifftcoe*ifftn(Kz.*U1_mid_t));
    U2_mid_t=reshape(U2_n2_t_f,N,N,N);  U2_mid=real(ifftcoe*ifftn(U2_mid_t));  U2_mid_x=real(ifftcoe*ifftn(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifftn(Ky.*U2_mid_t));  U2_mid_z=real(ifftcoe*ifftn(Kz.*U2_mid_t));
    U3_mid_t=reshape(U3_n2_t_f,N,N,N);  U3_mid=real(ifftcoe*ifftn(U3_mid_t));  U3_mid_x=real(ifftcoe*ifftn(Kx.*U3_mid_t));  U3_mid_y=real(ifftcoe*ifftn(Ky.*U3_mid_t));  U3_mid_z=real(ifftcoe*ifftn(Kz.*U3_mid_t));
    G1_mid_t=fftcoe*fftn(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y+U3_mid.*U1_mid_z);  G1_mid_t(1,1,1)=0;  G1_mid_t=G1_mid_t./Kxxyyzz_p; 
    G2_mid_t=fftcoe*fftn(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y+U3_mid.*U2_mid_z);  G2_mid_t(1,1,1)=0;  G2_mid_t=G2_mid_t./Kxxyyzz_p; 
    G3_mid_t=fftcoe*fftn(U1_mid.*U3_mid_x+U2_mid.*U3_mid_y+U3_mid.*U3_mid_z);  G3_mid_t(1,1,1)=0;  G3_mid_t=G3_mid_t./Kxxyyzz_p;
    F1_mid_t=(-1)*Kyyzz.*G1_mid_t+Kxy.*G2_mid_t+Kxz.*G3_mid_t;  F1_mid_t_f=F1_mid_t(:);
    F2_mid_t=(-1)*Kxxzz.*G2_mid_t+Kxy.*G1_mid_t+Kzy.*G3_mid_t;  F2_mid_t_f=F2_mid_t(:);
    F3_mid_t=(-1)*Kxxyy.*G3_mid_t+Kxz.*G1_mid_t+Kzy.*G2_mid_t;  F3_mid_t_f=F3_mid_t(:);
    N1_n2_t_f=F1_mid_t_f+LU1_t_f;  N2_n2_t_f=F2_mid_t_f+LU2_t_f;  N3_n2_t_f=F3_mid_t_f+LU3_t_f; 
    U1_n3_t_f=U1_t_f+tau*A31*N1_n1_t_f+tau*A32*N1_n2_t_f;  U2_n3_t_f=U2_t_f+tau*A31*N2_n1_t_f+tau*A32*N2_n2_t_f;  U3_n3_t_f=U3_t_f+tau*A31*N3_n1_t_f+tau*A32*N3_n2_t_f;
    %%%% U1_new_t_f  U2_new_t_f  U3_new_t_f
    U1_mid_t=reshape(U1_n3_t_f,N,N,N);  U1_mid=real(ifftcoe*ifftn(U1_mid_t));  U1_mid_x=real(ifftcoe*ifftn(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifftn(Ky.*U1_mid_t));  U1_mid_z=real(ifftcoe*ifftn(Kz.*U1_mid_t));
    U2_mid_t=reshape(U2_n3_t_f,N,N,N);  U2_mid=real(ifftcoe*ifftn(U2_mid_t));  U2_mid_x=real(ifftcoe*ifftn(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifftn(Ky.*U2_mid_t));  U2_mid_z=real(ifftcoe*ifftn(Kz.*U2_mid_t));
    U3_mid_t=reshape(U3_n3_t_f,N,N,N);  U3_mid=real(ifftcoe*ifftn(U3_mid_t));  U3_mid_x=real(ifftcoe*ifftn(Kx.*U3_mid_t));  U3_mid_y=real(ifftcoe*ifftn(Ky.*U3_mid_t));  U3_mid_z=real(ifftcoe*ifftn(Kz.*U3_mid_t));
    G1_mid_t=fftcoe*fftn(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y+U3_mid.*U1_mid_z);  G1_mid_t(1,1,1)=0;  G1_mid_t=G1_mid_t./Kxxyyzz_p; 
    G2_mid_t=fftcoe*fftn(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y+U3_mid.*U2_mid_z);  G2_mid_t(1,1,1)=0;  G2_mid_t=G2_mid_t./Kxxyyzz_p; 
    G3_mid_t=fftcoe*fftn(U1_mid.*U3_mid_x+U2_mid.*U3_mid_y+U3_mid.*U3_mid_z);  G3_mid_t(1,1,1)=0;  G3_mid_t=G3_mid_t./Kxxyyzz_p;
    F1_mid_t=(-1)*Kyyzz.*G1_mid_t+Kxy.*G2_mid_t+Kxz.*G3_mid_t;  F1_mid_t_f=F1_mid_t(:);
    F2_mid_t=(-1)*Kxxzz.*G2_mid_t+Kxy.*G1_mid_t+Kzy.*G3_mid_t;  F2_mid_t_f=F2_mid_t(:);
    F3_mid_t=(-1)*Kxxyy.*G3_mid_t+Kxz.*G1_mid_t+Kzy.*G2_mid_t;  F3_mid_t_f=F3_mid_t(:);
    N1_n3_t_f=F1_mid_t_f+LU1_t_f;  N2_n3_t_f=F2_mid_t_f+LU2_t_f;  N3_n3_t_f=F3_mid_t_f+LU3_t_f; 
    U1_new_t_f=U1_t_f+tau*B1*N1_n1_t_f+tau*B3*N1_n3_t_f;  U2_new_t_f=U2_t_f+tau*B1*N2_n1_t_f+tau*B3*N2_n3_t_f;  U3_new_t_f=U3_t_f+tau*B1*N3_n1_t_f+tau*B3*N3_n3_t_f;   
    U1_Update_t_f=U1_new_t_f-U1_t_f;  U2_Update_t_f=U2_new_t_f-U2_t_f;  U3_Update_t_f=U3_new_t_f-U3_t_f;  
    Update_norm=sum(abs(U1_Update_t_f))+sum(abs(U2_Update_t_f))+sum(abs(U3_Update_t_f));
    if ( Update_norm==0 )
        gamma=1;
    else
        key=2*tau*b1*real(U1_n1_t_f'*L*U1_n1_t_f+U2_n1_t_f'*L*U2_n1_t_f+U3_n1_t_f'*L*U3_n1_t_f) ...
           +2*tau*b3*real(U1_n3_t_f'*L*U1_n3_t_f+U2_n3_t_f'*L*U2_n3_t_f+U3_n3_t_f'*L*U3_n3_t_f);
        gamma=(key-2*real(U1_t_f'*U1_Update_t_f)-2*real(U2_t_f'*U2_Update_t_f)-2*real(U3_t_f'*U3_Update_t_f))/(real(U1_Update_t_f'*U1_Update_t_f)+real(U2_Update_t_f'*U2_Update_t_f)+real(U3_Update_t_f'*U3_Update_t_f));
        fprintf('distance=%d, Update=%d',abs(gamma-1),Update_norm);
    end
    tmesh=[tmesh tn];
    U1_t_f_save=U1_t_f;  U2_t_f_save=U2_t_f;  U3_t_f_save=U3_t_f;  tn_save=tn;
    GAMMA=[GAMMA gamma];  U1_t_f=U1_t_f+gamma*U1_Update_t_f;  U2_t_f=U2_t_f+gamma*U2_Update_t_f;  U3_t_f=U3_t_f+gamma*U3_Update_t_f;  tn=tn+gamma*tau
end

if ( (T-tn)<=0 )
    GAMMA=GAMMA(1:end-1);  tmesh=tmesh(1:end-1);    
    U1_t_f=U1_t_f_save;  U2_t_f=U2_t_f_save;  U3_t_f=U3_t_f_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
A21=c2*phipade(c2*tau*L,1);  
A32=(8/9)*phipade(c3*tau*L,2);  A31=c3*phipade(c3*tau*L,1)-A32;
B3=(3/2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B3;
%%%% U1_n1_t_f  U2_n1_t_f  U3_n1_t_f
LU1_t_f=L*U1_t_f;  LU2_t_f=L*U2_t_f;  LU3_t_f=L*U3_t_f;
U1_n1_t_f=U1_t_f;  U2_n1_t_f=U2_t_f;  U3_n1_t_f=U3_t_f;
%%%% U1_n2_t_f  U2_n2_t_f  U3_n2_t_f
U1_mid_t=reshape(U1_n1_t_f,N,N,N);  U1_mid=real(ifftcoe*ifftn(U1_mid_t));  U1_mid_x=real(ifftcoe*ifftn(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifftn(Ky.*U1_mid_t));  U1_mid_z=real(ifftcoe*ifftn(Kz.*U1_mid_t));
U2_mid_t=reshape(U2_n1_t_f,N,N,N);  U2_mid=real(ifftcoe*ifftn(U2_mid_t));  U2_mid_x=real(ifftcoe*ifftn(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifftn(Ky.*U2_mid_t));  U2_mid_z=real(ifftcoe*ifftn(Kz.*U2_mid_t));
U3_mid_t=reshape(U3_n1_t_f,N,N,N);  U3_mid=real(ifftcoe*ifftn(U3_mid_t));  U3_mid_x=real(ifftcoe*ifftn(Kx.*U3_mid_t));  U3_mid_y=real(ifftcoe*ifftn(Ky.*U3_mid_t));  U3_mid_z=real(ifftcoe*ifftn(Kz.*U3_mid_t));
G1_mid_t=fftcoe*fftn(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y+U3_mid.*U1_mid_z);  G1_mid_t(1,1,1)=0;  G1_mid_t=G1_mid_t./Kxxyyzz_p; 
G2_mid_t=fftcoe*fftn(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y+U3_mid.*U2_mid_z);  G2_mid_t(1,1,1)=0;  G2_mid_t=G2_mid_t./Kxxyyzz_p; 
G3_mid_t=fftcoe*fftn(U1_mid.*U3_mid_x+U2_mid.*U3_mid_y+U3_mid.*U3_mid_z);  G3_mid_t(1,1,1)=0;  G3_mid_t=G3_mid_t./Kxxyyzz_p;
F1_mid_t=(-1)*Kyyzz.*G1_mid_t+Kxy.*G2_mid_t+Kxz.*G3_mid_t;  F1_mid_t_f=F1_mid_t(:);
F2_mid_t=(-1)*Kxxzz.*G2_mid_t+Kxy.*G1_mid_t+Kzy.*G3_mid_t;  F2_mid_t_f=F2_mid_t(:);
F3_mid_t=(-1)*Kxxyy.*G3_mid_t+Kxz.*G1_mid_t+Kzy.*G2_mid_t;  F3_mid_t_f=F3_mid_t(:);
N1_n1_t_f=F1_mid_t_f+LU1_t_f;  N2_n1_t_f=F2_mid_t_f+LU2_t_f;  N3_n1_t_f=F3_mid_t_f+LU3_t_f; 
U1_n2_t_f=U1_t_f+tau*A21*N1_n1_t_f;  U2_n2_t_f=U2_t_f+tau*A21*N2_n1_t_f;  U3_n2_t_f=U3_t_f+tau*A21*N3_n1_t_f;
%%%% U1_n3_t_f  U2_n3_t_f  U3_n3_t_f
U1_mid_t=reshape(U1_n2_t_f,N,N,N);  U1_mid=real(ifftcoe*ifftn(U1_mid_t));  U1_mid_x=real(ifftcoe*ifftn(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifftn(Ky.*U1_mid_t));  U1_mid_z=real(ifftcoe*ifftn(Kz.*U1_mid_t));
U2_mid_t=reshape(U2_n2_t_f,N,N,N);  U2_mid=real(ifftcoe*ifftn(U2_mid_t));  U2_mid_x=real(ifftcoe*ifftn(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifftn(Ky.*U2_mid_t));  U2_mid_z=real(ifftcoe*ifftn(Kz.*U2_mid_t));
U3_mid_t=reshape(U3_n2_t_f,N,N,N);  U3_mid=real(ifftcoe*ifftn(U3_mid_t));  U3_mid_x=real(ifftcoe*ifftn(Kx.*U3_mid_t));  U3_mid_y=real(ifftcoe*ifftn(Ky.*U3_mid_t));  U3_mid_z=real(ifftcoe*ifftn(Kz.*U3_mid_t));
G1_mid_t=fftcoe*fftn(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y+U3_mid.*U1_mid_z);  G1_mid_t(1,1,1)=0;  G1_mid_t=G1_mid_t./Kxxyyzz_p; 
G2_mid_t=fftcoe*fftn(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y+U3_mid.*U2_mid_z);  G2_mid_t(1,1,1)=0;  G2_mid_t=G2_mid_t./Kxxyyzz_p; 
G3_mid_t=fftcoe*fftn(U1_mid.*U3_mid_x+U2_mid.*U3_mid_y+U3_mid.*U3_mid_z);  G3_mid_t(1,1,1)=0;  G3_mid_t=G3_mid_t./Kxxyyzz_p;
F1_mid_t=(-1)*Kyyzz.*G1_mid_t+Kxy.*G2_mid_t+Kxz.*G3_mid_t;  F1_mid_t_f=F1_mid_t(:);
F2_mid_t=(-1)*Kxxzz.*G2_mid_t+Kxy.*G1_mid_t+Kzy.*G3_mid_t;  F2_mid_t_f=F2_mid_t(:);
F3_mid_t=(-1)*Kxxyy.*G3_mid_t+Kxz.*G1_mid_t+Kzy.*G2_mid_t;  F3_mid_t_f=F3_mid_t(:);
N1_n2_t_f=F1_mid_t_f+LU1_t_f;  N2_n2_t_f=F2_mid_t_f+LU2_t_f;  N3_n2_t_f=F3_mid_t_f+LU3_t_f; 
U1_n3_t_f=U1_t_f+tau*A31*N1_n1_t_f+tau*A32*N1_n2_t_f;  U2_n3_t_f=U2_t_f+tau*A31*N2_n1_t_f+tau*A32*N2_n2_t_f;  U3_n3_t_f=U3_t_f+tau*A31*N3_n1_t_f+tau*A32*N3_n2_t_f;
%%%% U1_new_t_f  U2_new_t_f  U3_new_t_f
U1_mid_t=reshape(U1_n3_t_f,N,N,N);  U1_mid=real(ifftcoe*ifftn(U1_mid_t));  U1_mid_x=real(ifftcoe*ifftn(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifftn(Ky.*U1_mid_t));  U1_mid_z=real(ifftcoe*ifftn(Kz.*U1_mid_t));
U2_mid_t=reshape(U2_n3_t_f,N,N,N);  U2_mid=real(ifftcoe*ifftn(U2_mid_t));  U2_mid_x=real(ifftcoe*ifftn(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifftn(Ky.*U2_mid_t));  U2_mid_z=real(ifftcoe*ifftn(Kz.*U2_mid_t));
U3_mid_t=reshape(U3_n3_t_f,N,N,N);  U3_mid=real(ifftcoe*ifftn(U3_mid_t));  U3_mid_x=real(ifftcoe*ifftn(Kx.*U3_mid_t));  U3_mid_y=real(ifftcoe*ifftn(Ky.*U3_mid_t));  U3_mid_z=real(ifftcoe*ifftn(Kz.*U3_mid_t));
G1_mid_t=fftcoe*fftn(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y+U3_mid.*U1_mid_z);  G1_mid_t(1,1,1)=0;  G1_mid_t=G1_mid_t./Kxxyyzz_p; 
G2_mid_t=fftcoe*fftn(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y+U3_mid.*U2_mid_z);  G2_mid_t(1,1,1)=0;  G2_mid_t=G2_mid_t./Kxxyyzz_p; 
G3_mid_t=fftcoe*fftn(U1_mid.*U3_mid_x+U2_mid.*U3_mid_y+U3_mid.*U3_mid_z);  G3_mid_t(1,1,1)=0;  G3_mid_t=G3_mid_t./Kxxyyzz_p;
F1_mid_t=(-1)*Kyyzz.*G1_mid_t+Kxy.*G2_mid_t+Kxz.*G3_mid_t;  F1_mid_t_f=F1_mid_t(:);
F2_mid_t=(-1)*Kxxzz.*G2_mid_t+Kxy.*G1_mid_t+Kzy.*G3_mid_t;  F2_mid_t_f=F2_mid_t(:);
F3_mid_t=(-1)*Kxxyy.*G3_mid_t+Kxz.*G1_mid_t+Kzy.*G2_mid_t;  F3_mid_t_f=F3_mid_t(:);
N1_n3_t_f=F1_mid_t_f+LU1_t_f;  N2_n3_t_f=F2_mid_t_f+LU2_t_f;  N3_n3_t_f=F3_mid_t_f+LU3_t_f; 
U1_t_f=U1_t_f+tau*B1*N1_n1_t_f+tau*B3*N1_n3_t_f;  U2_t_f=U2_t_f+tau*B1*N2_n1_t_f+tau*B3*N2_n3_t_f;  U3_t_f=U3_t_f+tau*B1*N3_n1_t_f+tau*B3*N3_n3_t_f;  tn=tn+tau

