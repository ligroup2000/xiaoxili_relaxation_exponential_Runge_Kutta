stepsize=[1/4 1/8 1/16 1/32 1/64];
Gauss_time=[];  Gauss_err=[];  ERK_time=[];  ERK_err=[];
for k=1:size(stepsize,2)
    tau=stepsize(k);
    % [ERKerr,ERKtime]=ERK22(tau);  [GAUSSerr,GAUSStime]=Gauss2(tau);
    [ERKerr,ERKtime]=ERK44(tau);  [GAUSSerr,GAUSStime]=Gauss4(tau);
    ERK_err=[ERK_err ERKerr];  ERK_time=[ERK_time ERKtime];
    Gauss_err=[Gauss_err GAUSSerr];  Gauss_time=[Gauss_time GAUSStime];
end