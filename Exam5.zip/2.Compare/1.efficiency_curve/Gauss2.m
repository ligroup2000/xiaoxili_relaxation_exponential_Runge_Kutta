function [err,time]=Gauss2(tau)
%%%%%%%%%%%%%%%% 1-stages %%%%%%%%%%%%%%%%
A=1/2;  b=1;  c=1/2;
%%%%%%%%%%%%%%%% 2-stages %%%%%%%%%%%%%%%%
% A=[1/4 1/4-sqrt(3)/6; 1/4+sqrt(3)/6 1/4];
% b=[1/2 1/2];
% c=[1/2-sqrt(3)/6; 1/2+sqrt(3)/6];
%%%%%%%%%%%%%%%% 3-stages %%%%%%%%%%%%%%%%
% A=[5/36 2/9-sqrt(15)/15 5/36-sqrt(15)/30; ...
%    5/36+sqrt(15)/24 2/9 5/36-sqrt(15)/24; ...
%    5/36+sqrt(15)/30 2/9+sqrt(15)/15 5/36];
% b=[5/18 4/9 5/18];
% c=[1/2-sqrt(15)/10; 1/2; 1/2+sqrt(15)/10];
%%%%%%%%%%%%%%%% 4-stages %%%%%%%%%%%%%%%%
% w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
% w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
% w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
% w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
% A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
%    w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
%    w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
%    w1+w5 w11+w3+w44 w11+w3-w44 w1];
% b=[2*w1 2*w11 2*w11 2*w1];
% c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

tic;
nu=1;  T=1;  Le=-pi;  Re=pi;  N=64;  h=(Re-Le)/N;  area=(Re-Le)^3;
xmesh=Le:h:Re-h;  ymesh=xmesh;  zmesh=xmesh;  [X,Y,Z]=meshgrid(xmesh,ymesh,zmesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  z_freq=x_freq;  [X_freq,Y_freq,Z_freq]=meshgrid(x_freq,y_freq,z_freq);
Kx=1i*X_freq;  Ky=1i*Y_freq;  Kz=1i*Z_freq;  
Kxx=(-1)*X_freq.^2;  Kyy=(-1)*Y_freq.^2;  Kzz=(-1)*Z_freq.^2;  Kyyzz=Kyy+Kzz;  Kxxzz=Kxx+Kzz;  Kxxyy=Kxx+Kyy;   
Kxy=(-1)*X_freq.*Y_freq;  Kxz=(-1)*X_freq.*Z_freq;  Kzy=(-1)*Z_freq.*Y_freq; 
Kxxyyzz=Kxx+Kyy+Kzz;  Kxxyyzz_p=Kxxyyzz;  Kxxyyzz_p(1,1,1)=area; 
Kxxyyzz_f=spdiags(Kxxyyzz(:),0,N^3,N^3);
L=nu*Kxxyyzz_f;  LL=[L sparse(N^3,N^3) sparse(N^3,N^3); sparse(N^3,N^3) L sparse(N^3,N^3); sparse(N^3,N^3) sparse(N^3,N^3) L];

s=size(b,2);  Matrix1=(speye(s*3*N^3)-tau*kron(A,LL))^(-1);  Matrix2=tau*kron(A,speye(3*N^3));  Fmid=zeros(3*N^3,s);
matrix1=tau*kron(b,LL);  matrix2=tau*kron(b,speye(3*N^3));
 
fftcoe=1/N/N/N;  ifftcoe=N*N*N;
U1=sin(X).*cos(Y).*cos(Z);  U1_t=fftcoe*fftn(U1); 
U2=-cos(X).*sin(Y).*cos(Z);  U2_t=fftcoe*fftn(U2);
U3=zeros(N,N,N);  U3_t=fftcoe*fftn(U3);  
U1_t_f=U1_t(:);  U2_t_f=U2_t(:);  U3_t_f=U3_t(:);  U_t_f=[U1_t_f;U2_t_f;U3_t_f];

for k=1:(T/tau)
    iter_err=1;  iter_count=1;  U_mid=kron(ones(s,1),U_t_f);  U_last=Matrix1*U_mid;
    while ( (iter_err>10^(-16)) && (iter_count<100) )
        for kk=1:s
            U1_mid_t_f=U_mid((kk-1)*3*N^3+1:(kk-1)*3*N^3+N^3);  
            U2_mid_t_f=U_mid((kk-1)*3*N^3+N^3+1:(kk-1)*3*N^3+2*N^3);
            U3_mid_t_f=U_mid((kk-1)*3*N^3+2*N^3+1:kk*3*N^3);
            U1_mid_t=reshape(U1_mid_t_f,N,N,N);  U1_mid=real(ifftcoe*ifftn(U1_mid_t));  U1_mid_x=real(ifftcoe*ifftn(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifftn(Ky.*U1_mid_t));  U1_mid_z=real(ifftcoe*ifftn(Kz.*U1_mid_t));
            U2_mid_t=reshape(U2_mid_t_f,N,N,N);  U2_mid=real(ifftcoe*ifftn(U2_mid_t));  U2_mid_x=real(ifftcoe*ifftn(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifftn(Ky.*U2_mid_t));  U2_mid_z=real(ifftcoe*ifftn(Kz.*U2_mid_t));
            U3_mid_t=reshape(U3_mid_t_f,N,N,N);  U3_mid=real(ifftcoe*ifftn(U3_mid_t));  U3_mid_x=real(ifftcoe*ifftn(Kx.*U3_mid_t));  U3_mid_y=real(ifftcoe*ifftn(Ky.*U3_mid_t));  U3_mid_z=real(ifftcoe*ifftn(Kz.*U3_mid_t));
            G1_mid_t=fftcoe*fftn(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y+U3_mid.*U1_mid_z);  G1_mid_t(1,1,1)=0;  G1_mid_t=G1_mid_t./Kxxyyzz_p; 
            G2_mid_t=fftcoe*fftn(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y+U3_mid.*U2_mid_z);  G2_mid_t(1,1,1)=0;  G2_mid_t=G2_mid_t./Kxxyyzz_p; 
            G3_mid_t=fftcoe*fftn(U1_mid.*U3_mid_x+U2_mid.*U3_mid_y+U3_mid.*U3_mid_z);  G3_mid_t(1,1,1)=0;  G3_mid_t=G3_mid_t./Kxxyyzz_p;
            F1_mid_t=(-1)*Kyyzz.*G1_mid_t+Kxy.*G2_mid_t+Kxz.*G3_mid_t;  
            F2_mid_t=(-1)*Kxxzz.*G2_mid_t+Kxy.*G1_mid_t+Kzy.*G3_mid_t;  
            F3_mid_t=(-1)*Kxxyy.*G3_mid_t+Kxz.*G1_mid_t+Kzy.*G2_mid_t; 
            Fmid(:,kk)=[F1_mid_t(:);F2_mid_t(:);F3_mid_t(:)];
        end
        U_mid_save=U_mid;
        U_mid=U_last+Matrix1*Matrix2*Fmid(:);
        iter_err=max(abs(U_mid_save-U_mid));
        iter_count=iter_count+1;
    end
    for kk=1:s
        U1_mid_t_f=U_mid((kk-1)*3*N^3+1:(kk-1)*3*N^3+N^3);  
        U2_mid_t_f=U_mid((kk-1)*3*N^3+N^3+1:(kk-1)*3*N^3+2*N^3);
        U3_mid_t_f=U_mid((kk-1)*3*N^3+2*N^3+1:kk*3*N^3);
        U1_mid_t=reshape(U1_mid_t_f,N,N,N);  U1_mid=real(ifftcoe*ifftn(U1_mid_t));  U1_mid_x=real(ifftcoe*ifftn(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifftn(Ky.*U1_mid_t));  U1_mid_z=real(ifftcoe*ifftn(Kz.*U1_mid_t));
        U2_mid_t=reshape(U2_mid_t_f,N,N,N);  U2_mid=real(ifftcoe*ifftn(U2_mid_t));  U2_mid_x=real(ifftcoe*ifftn(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifftn(Ky.*U2_mid_t));  U2_mid_z=real(ifftcoe*ifftn(Kz.*U2_mid_t));
        U3_mid_t=reshape(U3_mid_t_f,N,N,N);  U3_mid=real(ifftcoe*ifftn(U3_mid_t));  U3_mid_x=real(ifftcoe*ifftn(Kx.*U3_mid_t));  U3_mid_y=real(ifftcoe*ifftn(Ky.*U3_mid_t));  U3_mid_z=real(ifftcoe*ifftn(Kz.*U3_mid_t));
        G1_mid_t=fftcoe*fftn(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y+U3_mid.*U1_mid_z);  G1_mid_t(1,1,1)=0;  G1_mid_t=G1_mid_t./Kxxyyzz_p; 
        G2_mid_t=fftcoe*fftn(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y+U3_mid.*U2_mid_z);  G2_mid_t(1,1,1)=0;  G2_mid_t=G2_mid_t./Kxxyyzz_p; 
        G3_mid_t=fftcoe*fftn(U1_mid.*U3_mid_x+U2_mid.*U3_mid_y+U3_mid.*U3_mid_z);  G3_mid_t(1,1,1)=0;  G3_mid_t=G3_mid_t./Kxxyyzz_p;
        F1_mid_t=(-1)*Kyyzz.*G1_mid_t+Kxy.*G2_mid_t+Kxz.*G3_mid_t;  
        F2_mid_t=(-1)*Kxxzz.*G2_mid_t+Kxy.*G1_mid_t+Kzy.*G3_mid_t;  
        F3_mid_t=(-1)*Kxxyy.*G3_mid_t+Kxz.*G1_mid_t+Kzy.*G2_mid_t; 
        Fmid(:,kk)=[F1_mid_t(:);F2_mid_t(:);F3_mid_t(:)];
    end
    U_t_f=U_t_f+matrix1*U_mid+matrix2*Fmid(:);
    k
end

U_t_f1=U_t_f;
load U_4stage_Gauss_nu=1_1000.mat
err=max(abs(U_t_f1-U_t_f));

time=toc;
