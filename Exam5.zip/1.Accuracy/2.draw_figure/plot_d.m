%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.24;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.41;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

load RERK22.mat
stepsize2=stepsize(2:end-1);  Gamma_dist_ave2=Gamma_Ave_save(2:end-1);
load RERK33.mat
stepsize3=stepsize(2:end-1);  Gamma_dist_ave3=Gamma_Ave_save(2:end-1);
load RERK44.mat
stepsize4=stepsize(2:end-1);  Gamma_dist_ave4=Gamma_Ave_save(2:end-1);

axes(p(1));    % ��ȡ��ǰfigure����Ϣ
loglog(stepsize2,Gamma_dist_ave2,'-ro','LineWidth',2,'MarkerSize',10,'MarkerFaceColor','r');  hold on;
loglog(stepsize3,Gamma_dist_ave3,'-gd','LineWidth',2,'MarkerSize',10,'MarkerFaceColor','g');
loglog(stepsize4,Gamma_dist_ave4,'-bs','LineWidth',2,'MarkerSize',10,'MarkerFaceColor','b');
loglog([stepsize2(end) stepsize2(end-1)],[3*Gamma_dist_ave2(end) 3*2*Gamma_dist_ave2(end)],':r','LineWidth',2);
loglog([stepsize3(end) stepsize3(end-1)],[3*Gamma_dist_ave3(end) 3*4*Gamma_dist_ave3(end)],':g','LineWidth',2);
loglog([stepsize4(end) stepsize4(end-1)],[3*Gamma_dist_ave4(end) 3*8*Gamma_dist_ave4(end)],':b','LineWidth',2);
box on;  set(gca,'linewidth',2,'FontSize',30)
set(gca,'XLim',[0.01 0.4])
set(gca,'YLim',[10^(-7) 0.5])
set(gca,'xTick',[0.01, 0.1]);  set(gca,'XTickLabel',{'10^{-2}','10^{-1}'});
set(gca,'yTick',[10^(-6),10^(-4),10^(-2)]);  set(gca,'YTickLabel',{'10^{-6}','10^{-4}','10^{-2}'});
xlabel('\tau','FontSize',30)
ylabel('$d(\gamma_n)$','interpreter','latex','FontSize',30)
legend('RERK(2,2)','RERK(3,3)','RERK(4,4)','slope=1','slope=2','slope=3')
set(legend,'interpreter','latex','location','southeast','FontSize',24) 