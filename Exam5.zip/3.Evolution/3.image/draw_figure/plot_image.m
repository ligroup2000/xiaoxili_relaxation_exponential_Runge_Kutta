load draw_matrix
load ERK44-25

%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 2;     % ��ͼ����
TightPlot.RowNumber = 3;    % ��ͼ����
TightPlot.GapW = 0.035;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.07;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.06;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.02;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.05;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.25;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

axes(p(1));    % ��ȡ��ǰfigure����Ϣ
W=real(ifftn(Kz.*reshape(U2_t_f_save(:,1),N,N,N)-Ky.*reshape(U3_t_f_save(:,1),N,N,N))); 
WW=zeros(N+1,N+1,N+1);
WW(1:N,1:N,1:N)=W;  
WW(1:N,1:N,N+1)=W(1:N,1:N,1);  
WW(1:N,1+N,1:N+1)=WW(1:N,1,1:N+1);  
WW(1+N,1:N+1,1:N+1)=WW(1,1:N+1,1:N+1);  
WW(N+1,N+1,1:N+1)=WW(1,1,1:N+1);
Le=-pi;  Re=pi;  N=128;  h=(Re-Le)/N;  area=(Re-Le)^3;
xmesh=Le:h:Re;  ymesh=xmesh;  zmesh=xmesh;  [X,Y,Z]=meshgrid(xmesh,ymesh,zmesh); 
isosurface(X,Y,Z,WW,-3);
set(gca,'XLim',[-pi,pi])
set(gca,'YLim',[-pi,pi])
set(gca,'ZLim',[-pi,pi])
set(gca,'xtick',[],'ytick',[],'ztick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
zlabel('$z$','interpreter','latex','FontSize',20)
box on;  
view(-60,30);
brighten(0.5);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(2));    % ��ȡ��ǰfigure����Ϣ
W=real(ifftn(Kz.*reshape(U2_t_f_save(:,2),N,N,N)-Ky.*reshape(U3_t_f_save(:,2),N,N,N))); 
WW=zeros(N+1,N+1,N+1);
WW(1:N,1:N,1:N)=W;  
WW(1:N,1:N,N+1)=W(1:N,1:N,1);  
WW(1:N,1+N,1:N+1)=WW(1:N,1,1:N+1);  
WW(1+N,1:N+1,1:N+1)=WW(1,1:N+1,1:N+1);  
WW(N+1,N+1,1:N+1)=WW(1,1,1:N+1);
Le=-pi;  Re=pi;  N=128;  h=(Re-Le)/N;  area=(Re-Le)^3;
xmesh=Le:h:Re;  ymesh=xmesh;  zmesh=xmesh;  [X,Y,Z]=meshgrid(xmesh,ymesh,zmesh); 
isosurface(X,Y,Z,WW,-3);
set(gca,'XLim',[-pi,pi])
set(gca,'YLim',[-pi,pi])
set(gca,'ZLim',[-pi,pi])
set(gca,'xtick',[],'ytick',[],'ztick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
zlabel('$z$','interpreter','latex','FontSize',20)
box on;  
view(-60,30);
% brighten(0.5);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(3));    % ��ȡ��ǰfigure����Ϣ
W=real(ifftn(Kz.*reshape(U2_t_f_save(:,3),N,N,N)-Ky.*reshape(U3_t_f_save(:,3),N,N,N))); 
WW=zeros(N+1,N+1,N+1);
WW(1:N,1:N,1:N)=W;  
WW(1:N,1:N,N+1)=W(1:N,1:N,1);  
WW(1:N,1+N,1:N+1)=WW(1:N,1,1:N+1);  
WW(1+N,1:N+1,1:N+1)=WW(1,1:N+1,1:N+1);  
WW(N+1,N+1,1:N+1)=WW(1,1,1:N+1);
Le=-pi;  Re=pi;  N=128;  h=(Re-Le)/N;  area=(Re-Le)^3;
xmesh=Le:h:Re;  ymesh=xmesh;  zmesh=xmesh;  [X,Y,Z]=meshgrid(xmesh,ymesh,zmesh); 
isosurface(X,Y,Z,WW,-3);
set(gca,'XLim',[-pi,pi])
set(gca,'YLim',[-pi,pi])
set(gca,'ZLim',[-pi,pi])
set(gca,'xtick',[],'ytick',[],'ztick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
zlabel('$z$','interpreter','latex','FontSize',20)
box on;  
view(-60,30);
% brighten(0.5);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(4));    % ��ȡ��ǰfigure����Ϣ
W=real(ifftn(Kz.*reshape(U2_t_f_save(:,4),N,N,N)-Ky.*reshape(U3_t_f_save(:,4),N,N,N))); 
WW=zeros(N+1,N+1,N+1);
WW(1:N,1:N,1:N)=W;  
WW(1:N,1:N,N+1)=W(1:N,1:N,1);  
WW(1:N,1+N,1:N+1)=WW(1:N,1,1:N+1);  
WW(1+N,1:N+1,1:N+1)=WW(1,1:N+1,1:N+1);  
WW(N+1,N+1,1:N+1)=WW(1,1,1:N+1);
Le=-pi;  Re=pi;  N=128;  h=(Re-Le)/N;  area=(Re-Le)^3;
xmesh=Le:h:Re;  ymesh=xmesh;  zmesh=xmesh;  [X,Y,Z]=meshgrid(xmesh,ymesh,zmesh); 
isosurface(X,Y,Z,WW,-3);
set(gca,'XLim',[-pi,pi])
set(gca,'YLim',[-pi,pi])
set(gca,'ZLim',[-pi,pi])
set(gca,'xtick',[],'ytick',[],'ztick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
zlabel('$z$','interpreter','latex','FontSize',20)
box on;  
view(-60,30);
% brighten(0.5);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(5));    % ��ȡ��ǰfigure����Ϣ
W=real(ifftn(Kz.*reshape(U2_t_f_save(:,5),N,N,N)-Ky.*reshape(U3_t_f_save(:,5),N,N,N))); 
WW=zeros(N+1,N+1,N+1);
WW(1:N,1:N,1:N)=W;  
WW(1:N,1:N,N+1)=W(1:N,1:N,1);  
WW(1:N,1+N,1:N+1)=WW(1:N,1,1:N+1);  
WW(1+N,1:N+1,1:N+1)=WW(1,1:N+1,1:N+1);  
WW(N+1,N+1,1:N+1)=WW(1,1,1:N+1);
Le=-pi;  Re=pi;  N=128;  h=(Re-Le)/N;  area=(Re-Le)^3;
xmesh=Le:h:Re;  ymesh=xmesh;  zmesh=xmesh;  [X,Y,Z]=meshgrid(xmesh,ymesh,zmesh); 
isosurface(X,Y,Z,WW,-3);
set(gca,'XLim',[-pi,pi])
set(gca,'YLim',[-pi,pi])
set(gca,'ZLim',[-pi,pi])
set(gca,'xtick',[],'ytick',[],'ztick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
zlabel('$z$','interpreter','latex','FontSize',20)
box on;  
view(-60,30);
% brighten(0.5);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(6));    % ��ȡ��ǰfigure����Ϣ
W=real(ifftn(Kz.*reshape(U2_t_f_save(:,6),N,N,N)-Ky.*reshape(U3_t_f_save(:,6),N,N,N))); 
WW=zeros(N+1,N+1,N+1);
WW(1:N,1:N,1:N)=W;  
WW(1:N,1:N,N+1)=W(1:N,1:N,1);  
WW(1:N,1+N,1:N+1)=WW(1:N,1,1:N+1);  
WW(1+N,1:N+1,1:N+1)=WW(1,1:N+1,1:N+1);  
WW(N+1,N+1,1:N+1)=WW(1,1,1:N+1);
Le=-pi;  Re=pi;  N=128;  h=(Re-Le)/N;  area=(Re-Le)^3;
xmesh=Le:h:Re;  ymesh=xmesh;  zmesh=xmesh;  [X,Y,Z]=meshgrid(xmesh,ymesh,zmesh); 
isosurface(X,Y,Z,WW,-3);
set(gca,'XLim',[-pi,pi])
set(gca,'YLim',[-pi,pi])
set(gca,'ZLim',[-pi,pi])
set(gca,'xtick',[],'ytick',[],'ztick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
zlabel('$z$','interpreter','latex','FontSize',20)
box on;  
view(-60,30);
% brighten(0.5);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ