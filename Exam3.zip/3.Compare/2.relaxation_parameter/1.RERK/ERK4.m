function [tmesh,GAMMA]=ERK4(tau)

N=500;  T=4;  Le=-25;  Re=25;  p=1;  alpha=2; 
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  x1=-10;  x2=10;  Un=sech(xmesh-x1).*exp(2*1i*(xmesh-x1))+sech(xmesh-x2).*exp(-2*1i*(xmesh-x2));  Un_t=fftcoe*fft(Un); 
GAMMA=[];  tmesh=[];

c2=0.5;  c3=0.5;  c4=1;
tauL=tau*L;  tauL2=c2*tauL;  tauL3=c3*tauL;  tauL4=c4*tauL;
tauL(1)=1;  tauL2(1)=1;  tauL3(1)=1;  tauL4(1)=1;
%%%%  tauL  %%%%
phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
phi3=((exp(tauL)-1-tauL-0.5*tauL.^2)./(tauL.^3));  phi3(1,1)=1/6;
%%%%  tauL2  %%%%
phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
%%%%  tauL3  %%%%
phi13=(exp(tauL3)-1)./(tauL3);  phi13(1,1)=1;
phi23=((exp(tauL3)-1-tauL3)./(tauL3.^2));  phi23(1,1)=1/2;
%%%%  tauL4  %%%%
phi14=(exp(tauL4)-1)./(tauL4);  phi14(1,1)=1;
phi24=((exp(tauL4)-1-tauL4)./(tauL4.^2));  phi24(1,1)=1/2;
%%%%  coe_matrix %%%%
A21=0.5*phi12;
A31=0.5*phi13-phi23;  A32=phi23;
A41=phi14-2*phi24;  A42=zeros(N,1);  A43=2*phi24;
B1=phi1-3*phi2+4*phi3;  B2=2*phi2-4*phi3;  B3=2*phi2-4*phi3;  B4=-phi2+4*phi3;

while (tn<(T-tau))
    %%%% Un1_t
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t
    Un1=ifftcoe*ifft(Un1_t);  Gn1_t=fftcoe*fft(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Un3_t
    Un2=ifftcoe*ifft(Un2_t);  Gn2_t=fftcoe*fft(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    Un3_t=Un_t+tau*A31.*GLUn1_t+tau*A32.*GLUn2_t;
    %%%% Un4_t
    Un3=ifftcoe*ifft(Un3_t);  Gn3_t=fftcoe*fft(1i*(f(abs(Un3).^2).*Un3));  GLUn3_t=Gn3_t+LUn_t;
    Un4_t=Un_t+tau*A41.*GLUn1_t+tau*A42.*GLUn2_t+tau*A43.*GLUn3_t;
    %%%% Unew_t
    Un4=ifftcoe*ifft(Un4_t);  Gn4_t=fftcoe*fft(1i*(f(abs(Un4).^2).*Un4));  GLUn4_t=Gn4_t+LUn_t;
    dn_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t+tau*B3.*GLUn3_t+tau*B4.*GLUn4_t;
    energy=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));
    %%%% compute gamma %%%%
    if ( sum(sum(abs(dn_t)))==0 )
        gamma=1;
    else
        [gamma,~]=func_gamma(f,Un_t,dn_t,F,h,area,Kxx,ifftcoe,energy);
    end
    fprintf('tn=%d,distance=%d\n',tn,abs(gamma-1));
    GAMMA=[GAMMA gamma];  tmesh=[tmesh tn];
    %%%% step update %%%%
    Un_t=Un_t+gamma*dn_t;  tn=tn+gamma*tau;
end

save('ERK44_10.mat','GAMMA','tmesh');