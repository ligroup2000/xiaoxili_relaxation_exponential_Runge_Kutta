function [tmesh,GAMMA]=RK44(tau)
warning off;
N=20;  left=-7;  right=7;  bottom=-7; top=7;  h=(right-left)/N;  
xmesh=left+0.5*h:h:right-0.5*h;  ymesh=bottom+0.5*h:h:top-0.5*h;  [XMESH,YMESH]=meshgrid(xmesh,ymesh); 
KK=diag(ones(N-1,1),1)+diag(ones(N-1,1),-1);  K=kron(KK,speye(N))+kron(speye(N),KK);  K=K+(-1)*diag(sum(K,2));  K=(1/h/h)*K;  d=size(K,1);  
K=10000*K;  L=[sparse(d,d) K;speye(d) sparse(d,d)];  Vn=zeros(d,1);  Un_temp=4*atan(exp(3-sqrt(XMESH.^2+YMESH.^2)));  Un=Un_temp(:);  Zn=[Vn;Un];
func_F=@(x)cos(x);  func_f=@(x)(-1)*(sin(x));

a21=0.5;  a32=0.5;  a43=1;
b1=1/6;  b2=1/3;  b3=1/3;  b4=1/6;

tmesh=[];  GAMMA=[];  Energy=[];
  
T=3;  tn=0; 
while (tn<(T-tau))
    %%%% Zn1
    Zn1=Zn;
    %%%% Zn2
    Fn1=compute_nonlinear(Zn1,func_f,d)+L*Zn1;  Zn2=Zn+tau*a21*Fn1;
    %%%% Zn3
    Fn2=compute_nonlinear(Zn2,func_f,d)+L*Zn2;  Zn3=Zn+tau*a32*Fn2;
    %%%% Zn4
    Fn3=compute_nonlinear(Zn3,func_f,d)+L*Zn3;  Zn4=Zn+tau*a43*Fn3;
    %%%% Znew
    Fn4=compute_nonlinear(Zn4,func_f,d)+L*Zn4;  Znew=Zn+tau*b1*Fn1+tau*b2*Fn2+tau*b3*Fn3+tau*b4*Fn4; 
    energy_old=compute_energy(Zn,d,h,func_F,K);  Energy=[Energy energy_old];  tmesh=[tmesh tn]; 
    Update=Znew-Zn;
    if ( (sum(abs(Update)))==0 )
        gamma=1;
    else
        gamma=fzero(@(gamma)func_of_gamma(Zn,Update,d,K,h,func_F,energy_old,gamma),1);
        fprintf('t=%d, distance=%d',tn,abs(gamma-1));
    end
    Zn_save=Zn;  tn_save=tn;
    GAMMA=[GAMMA gamma];  Zn=Zn+gamma*Update;  tn=tn+gamma*tau
end
energy_old=compute_energy(Zn,d,h,func_F,K);  Energy=[Energy energy_old];  tmesh=[tmesh tn]; 
