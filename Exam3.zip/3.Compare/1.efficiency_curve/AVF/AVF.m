function [CPUtime,err,energy_err]=AVF(tau)

tic;

N=500;  T=1;  Le=-25;  Re=25;  p=1;  alpha=2; 
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  x1=-10;  x2=10;  Un=sech(xmesh-x1).*exp(2*1i*(xmesh-x1))+sech(xmesh-x2).*exp(-2*1i*(xmesh-x2));  Un_t=fftcoe*fft(Un); 
[GP,GW]=generate_GP_GW;  Matrix=(ones(N,1)-0.5*tau*L).^(-1);  
Energy=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));

while (tn<(T-0.5*tau)) 
    iter_err=1;  iter_count=0;  Un1_t=Un_t;  
    while ((iter_err >= 10^(-14)) && (iter_count < 100))
        Unew=Un1_t-Un_t;
        U1_t=Un_t+GP(1)*Unew;  U2_t=Un_t+GP(2)*Unew;  U3_t=Un_t+GP(3)*Unew;  U4_t=Un_t+GP(4)*Unew;  U5_t=Un_t+GP(5)*Unew; 
        UU_t=[U1_t U2_t U3_t U4_t U5_t];  UU=ifftcoe*ifft(UU_t);  Nonlinear=(fftcoe*fft(1i*f(abs(UU).^2).*UU))*(GW');
        Un1_t_save=Un1_t;  Un1_t=Matrix.*(Un_t+0.5*tau*(L.*Un_t)+tau*Nonlinear);
        iter_err=max(abs(Un1_t_save-Un1_t));
        iter_count=iter_count+1;
    end
    Un_t=Un1_t;  tn=tn+tau;
    energy=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  Energy=[Energy energy];
end
toc;  CPUtime=toc;
load('reference_100000.mat');  err=max(abs(Un_t-Un_t_100000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));