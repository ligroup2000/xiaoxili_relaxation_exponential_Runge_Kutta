stepsize=[1/10 1/20 1/40 1/80 1/160];

ERR=[];  TIME=[];  Energy_Dis=[];
for k=1:size(stepsize,2)
    tau=stepsize(1,k);
    [CPUtime,err,energy_err]=AVF(tau); 
    TIME=[TIME CPUtime];
    ERR=[ERR err]; 
    Energy_Dis=[Energy_Dis energy_err];
end

Err_Order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end))

save('AVF.mat','TIME','ERR','Energy_Dis');
