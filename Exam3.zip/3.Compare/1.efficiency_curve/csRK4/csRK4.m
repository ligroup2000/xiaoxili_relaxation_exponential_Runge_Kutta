function [CPUtime,err,energy_err]=csRK4(tau)

tic;

N=500;  T=1;  Le=-25;  Re=25;  p=1;  alpha=2; 
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  x1=-10;  x2=10;  Un=sech(xmesh-x1).*exp(2*1i*(xmesh-x1))+sech(xmesh-x2).*exp(-2*1i*(xmesh-x2));  Un_t=fftcoe*fft(Un); 
[coe1,coe2,coe3,coe4,coe5,coe6,GW]=generate_coefficient;  
Ls=spdiags(L,0,N,N);  Matrix=(speye(2*N)-tau*[coe5(2)*Ls coe5(3)*Ls;coe6(2)*Ls coe6(3)*Ls])^(-1);  
Energy=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));

while (tn<(T-0.5*tau))
    iter_err=1;  iter_count=0;  ZZ_t=[Un_t;Un_t];  Yn_t=L.*Un_t;  
    while ((iter_err >= 10^(-14)) && (iter_count < 100))
        Um_t=ZZ_t(1:N,1);  Un1_t=ZZ_t(N+1:end,1);  
        Ym_t=L.*Um_t;  Yn1_t=L.*Un1_t;  
        U1_t=coe1(1)*Un_t+coe2(1)*Um_t+coe3(1)*Un1_t;  
        U2_t=coe1(2)*Un_t+coe2(2)*Um_t+coe3(2)*Un1_t; 
        U3_t=coe1(3)*Un_t+coe2(3)*Um_t+coe3(3)*Un1_t;   
        U4_t=coe1(4)*Un_t+coe2(4)*Um_t+coe3(4)*Un1_t;  
        U5_t=coe1(5)*Un_t+coe2(5)*Um_t+coe3(5)*Un1_t; 
        UU_t=[U1_t U2_t U3_t U4_t U5_t];  UU=ifftcoe*ifft(UU_t);  FF=fftcoe*fft(1i*f(abs(UU).^2).*UU);
        Nonlinear1=FF*(coe4');  Nonlinear2=FF*(GW');
        ZZ_t_save=ZZ_t;  ZZ_t=Matrix*([Un_t;Un_t]+tau*[coe5(1)*Yn_t;coe6(1)*Yn_t]+tau*[Nonlinear1;Nonlinear2]);
        iter_err=max(abs(ZZ_t_save-ZZ_t));
        iter_count=iter_count+1;
    end
    Un_t=ZZ_t(N+1:end,1);  tn=tn+tau;
    energy=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  Energy=[Energy energy];
end
toc;  CPUtime=toc;
load('reference_100000.mat');  err=max(abs(Un_t-Un_t_100000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));