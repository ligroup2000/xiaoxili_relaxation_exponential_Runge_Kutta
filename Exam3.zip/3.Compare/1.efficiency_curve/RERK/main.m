stepsize=[1/10 1/20 1/40 1/80 1/160];

TIME=[];  ERR=[];  Energy_Dis=[]; 
for k=1:size(stepsize,2)
    tau=stepsize(k); 
    [err,time,energy_discrepancy]=ERK2(tau);
    TIME=[TIME time];
    ERR=[ERR err]; 
    Energy_Dis=[Energy_Dis energy_discrepancy];
end
Err_Order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
save('ERK22.mat','TIME','ERR','Energy_Dis');
