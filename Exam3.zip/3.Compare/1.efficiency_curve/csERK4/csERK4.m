function [CPUtime,err,energy_err]=csERK4(tau)

tic;

N=500;  T=1;  Le=-25;  Re=25;  p=1;  alpha=2; 
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  x1=-10;  x2=10;  Un=sech(xmesh-x1).*exp(2*1i*(xmesh-x1))+sech(xmesh-x2).*exp(-2*1i*(xmesh-x2));  Un_t=fftcoe*fft(Un); 
[coe1,coe2,coe3,AA1,AA2,AA3,AA4,AA5,BB1,BB2,BB3,BB4,BB5,e5,e6]=generate_coefficient(tau,L); 
Energy=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));

while (tn<(T-0.5*tau))  
    iter_err=1;  iter_count=0;  KK=[e5.*Un_t;e6.*Un_t];  ZZ1=[Un_t;Un_t];
    while ( (iter_err > 10^(-12)) && (iter_count<10))
        Um_t=ZZ1(1:N,1);  Un1_t=ZZ1(N+1:end,1);
        U1_t=coe1(1)*Un_t+coe2(1)*Um_t+coe3(1)*Un1_t;  U2_t=coe1(2)*Un_t+coe2(2)*Um_t+coe3(2)*Un1_t;
        U3_t=coe1(3)*Un_t+coe2(3)*Um_t+coe3(3)*Un1_t;  U4_t=coe1(4)*Un_t+coe2(4)*Um_t+coe3(4)*Un1_t;
        U5_t=coe1(5)*Un_t+coe2(5)*Um_t+coe3(5)*Un1_t;
        UU_t=[U1_t U2_t U3_t U4_t U5_t];  UU=ifftcoe*ifft(UU_t);  Nonlinear=fftcoe*fft(1i*f(abs(UU).^2).*UU);
        F1=sum([AA1 AA2 AA3 AA4 AA5].*Nonlinear,2);  F2=sum([BB1 BB2 BB3 BB4 BB5].*Nonlinear,2);
        ZZ1_save=ZZ1;  ZZ1=KK+tau*[F1;F2];
        iter_err=max(abs(ZZ1_save-ZZ1));
        iter_count=iter_count+1;
    end
    Un_t=ZZ1(N+1:end,1);  tn=tn+tau;
    energy=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  Energy=[Energy energy];
end
toc;  CPUtime=toc;
load('reference_100000.mat');  err=max(abs(Un_t-Un_t_100000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));