stepsize=[1/10 1/20 1/40 1/80];
Err=[];  Gamma_average_save=[];
for k=1:size(stepsize,2)
    [err,gamma_average]=ERK4(stepsize(k));
    Err=[Err err];
    Gamma_average_save=[Gamma_average_save gamma_average];
end

Err_order=log(Err(1:end-1)./Err(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
Gamma_order=log(Gamma_average_save(1:end-1)./Gamma_average_save(2:end))./log(stepsize(1:end-1)./stepsize(2:end))