function Un_t=reference(tau)
N=500;  T=1;  Le=-25;  Re=25;  h=(Re-Le)/N;
xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
p=1;  alpha=2;
f=@(x)alpha*x.^p;
clear freq

w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];
 
fftcoe=1/N;  ifftcoe=N;  
x1=-10;  x2=10;  Un=sech(xmesh-x1).*exp(2*1i*(xmesh-x1))+sech(xmesh-x2).*exp(-2*1i*(xmesh-x2)); 
tn=0;  Un_t=fftcoe*fft(Un);

L_f=spdiags(L,0,N,N);  s=size(A,1);  es=ones(s,1);  Matrix=(speye(s*N)-tau*kron(A,L_f))^(-1);

while (tn<(T-0.5*tau))
    iter_err=1;  iter_count=0;  Ue=kron(es,Un_t);  Umid_t_f=Ue;
    while ((iter_err>10^(-14)) && (iter_count<100))
        Umid_t=reshape(Umid_t_f,N,s);  Umid=ifftcoe*ifft(Umid_t);  
        gmid_t=fftcoe*fft(1i*(f(abs(Umid).^2).*Umid));
        v1=tau*gmid_t*(A');
        vec=Ue+v1(:);
        Umid_t_f_save=Umid_t_f;  Umid_t_f=Matrix*vec;
        iter_err=max(abs(Umid_t_f_save-Umid_t_f));
        iter_count=iter_count+1;
    end
    Umid_t=reshape(Umid_t_f,N,s);  Umid=ifftcoe*ifft(Umid_t);  
    gmid_t=fftcoe*fft(1i*(f(abs(Umid).^2).*Umid));
    Un_t=Un_t+tau*L_f*Umid_t*(b')+tau*gmid_t*(b');
    tn=tn+tau
end