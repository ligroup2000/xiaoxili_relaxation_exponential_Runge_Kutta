stepsize=[1/320 1/640 1/1280 1/2560 1/5120 1/10240];
% stepsize=[1/20 1/40 1/80 1/160 1/320];
Un_save=[];  Err=[]; 

for k=1:size(stepsize,2)
    U=reference(stepsize(k));
    Un_save=[Un_save U(:)];
end

for k=1:size(stepsize,2)-1
    Err=[Err max(abs(Un_save(:,k)-Un_save(:,end)))];
end

Err_order=log(Err(1:end-1)./Err(2:end))./log(stepsize(1:end-2)./stepsize(2:end-1))