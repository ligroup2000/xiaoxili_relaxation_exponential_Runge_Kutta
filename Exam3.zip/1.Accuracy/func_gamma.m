function [gamma,iter_count]=func_gamma(f,Un_t,dn_t,F,h,area,Kxx,ifftcoe,energy)

a1=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-energy;
a2=-2*area*real(sum(conj(Un_t).*Kxx.*dn_t));
a3=-area*real(sum(conj(dn_t).*Kxx.*dn_t));
Un=ifftcoe*ifft(Un_t);  dn=ifftcoe*ifft(dn_t);  dn_conj=conj(dn);
iter_err=1;  iter_count=0;  gamma=1;
while ((iter_err>10^(-14)) && (iter_count < 5))
    Unext=Un+gamma*dn;
    vector=a1+a2*gamma+a3*gamma^2-h*sum(F(abs(Unext).^2));
    matrix=a2+2*gamma*a3-2*h*sum(real(f(abs(Unext).^2).*Unext.*dn_conj));
    gamma_save=gamma;  gamma=gamma-matrix\vector;
    iter_err=abs(gamma_save-gamma);  iter_count=iter_count+1;
end