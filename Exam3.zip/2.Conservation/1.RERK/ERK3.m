function [Energy,tmesh,CPUtime,Iter]=ERK3(tau)
tic;

N=500;  T=200;  Le=-25;  Re=25;  p=1;  alpha=2; 
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  x1=-10;  x2=10;  Un=sech(xmesh-x1).*exp(2*1i*(xmesh-x1))+sech(xmesh-x2).*exp(-2*1i*(xmesh-x2));  Un_t=fftcoe*fft(Un); 
Energy=[];  tmesh=[];  Iter=[];

c2=0.5;  c3=2/3;
tauL=tau*L;  tauL2=c2*tauL;  tauL3=c3*tauL;
tauL(1)=1;  tauL2(1)=1;  tauL3(1)=1;
%%%%  tauL  %%%%
phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
%%%%  tauL2  %%%%
phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
%%%%  tauL3  %%%%
phi13=(exp(tauL3)-1)./(tauL3);  phi13(1,1)=1;
phi23=((exp(tauL3)-1-tauL3)./(tauL3.^2));  phi23(1,1)=1/2;
%%%%  coe_matrix %%%%
A21=c2*phi12;
A31=(2/3)*phi13-(4/9/c2)*phi23;  A32=(4/9/c2)*phi23;
B1=phi1-(3/2)*phi2;  B2=zeros(N,1);  B3=(3/2)*phi2;

while (tn<(T-tau))
    %%%% Un1_t
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t
    Un1=ifftcoe*ifft(Un1_t);  Gn1_t=fftcoe*fft(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Un3_t
    Un2=ifftcoe*ifft(Un2_t);  Gn2_t=fftcoe*fft(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    Un3_t=Un_t+tau*A31.*GLUn1_t+tau*A32.*GLUn2_t;
    %%%% Unew_t
    Un3=ifftcoe*ifft(Un3_t);  Gn3_t=fftcoe*fft(1i*(f(abs(Un3).^2).*Un3));  GLUn3_t=Gn3_t+LUn_t;
    dn_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t+tau*B3.*GLUn3_t;
    energy=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  Energy=[Energy energy];  tmesh=[tmesh tn];
    %%%% compute gamma %%%%
    if ( sum(sum(abs(dn_t)))==0 )
        gamma=0;
    else
        [gamma,iter_count]=func_gamma(f,Un_t,dn_t,F,h,area,Kxx,ifftcoe,energy);
        Iter=[Iter iter_count];
    end
    %%%% step update %%%%
    Un_t=Un_t+gamma*dn_t;  tn=tn+gamma*tau
end
Energy=[Energy energy];  tmesh=[tmesh tn];

toc;
CPUtime=toc;
save('RERK33.mat','CPUtime','Energy','tmesh','Iter');