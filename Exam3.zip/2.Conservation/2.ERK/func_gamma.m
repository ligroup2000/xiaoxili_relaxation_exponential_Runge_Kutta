function result=func_gamma(gamma,Un_t,dn_t,F,h,area,Kxx,ifftcoe,energy)

Unext_t=Un_t+gamma*dn_t;
result=-area*real(sum(conj(Unext_t).*Kxx.*Unext_t))-h*sum(F((abs(ifftcoe*ifft(Unext_t))).^2))-energy;