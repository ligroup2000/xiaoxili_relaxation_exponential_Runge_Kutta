stepsize=[1/100 1/200 1/400 1/800 1/1600];
% stepsize=[1/20 1/40 1/80 1/160 1/320];
Un_save=[];  Err=[];  Gamma_Ave_save=[];  Gamma_Max_save=[];

for k=1:size(stepsize,2)
    [U,gamma_average,gamma_max]=ERK22(stepsize(k));
    Un_save=[Un_save U];
    Gamma_Ave_save=[Gamma_Ave_save gamma_average];
    Gamma_Max_save=[Gamma_Max_save gamma_max];
end

for k=1:size(stepsize,2)-1
    Err=[Err max(abs(Un_save(:,k)-Un_save(:,end)))];
end

Err_order=log(Err(1:end-1)./Err(2:end))./log(stepsize(1:end-2)./stepsize(2:end-1))
Gamma_Ave_order=log(Gamma_Ave_save(1:end-1)./Gamma_Ave_save(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
Gamma_Max_order=log(Gamma_Max_save(1:end-1)./Gamma_Max_save(2:end))./log(stepsize(1:end-1)./stepsize(2:end))