load U_4stage_Gauss_nu=0.01_rho=20_10000.mat
stepsize=[1/100 1/200 1/400 1/800 1/1600];  % ERK22,ERK33
% stepsize=[1/50 1/100 1/200 1/400 1/800];  % ERK44
Err=[];  Gamma_Ave_save=[];

for k=1:size(stepsize,2)
    [U,gamma_average]=ERK22(stepsize(k));
    Err=[Err max(abs(U-U_t_f))];
    Gamma_Ave_save=[Gamma_Ave_save gamma_average];
end

Err
Err_order=log(Err(1:end-1)./Err(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
GAMMA=GAMMA(1:end-1);
Gamma_Ave_order=log(Gamma_Ave_save(1:end-1)./Gamma_Ave_save(2:end))./log(stepsize(1:end-1)./stepsize(2:end))