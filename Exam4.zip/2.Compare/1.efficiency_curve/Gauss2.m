function [err,time]=Gauss2(tau)
%%%%%%%%%%%%%%%% 1-stages %%%%%%%%%%%%%%%%
A=1/2;  b=1;  c=1/2;
%%%%%%%%%%%%%%%% 2-stages %%%%%%%%%%%%%%%%
% A=[1/4 1/4-sqrt(3)/6; 1/4+sqrt(3)/6 1/4];
% b=[1/2 1/2];
% c=[1/2-sqrt(3)/6; 1/2+sqrt(3)/6];
%%%%%%%%%%%%%%%% 3-stages %%%%%%%%%%%%%%%%
% A=[5/36 2/9-sqrt(15)/15 5/36-sqrt(15)/30; ...
%    5/36+sqrt(15)/24 2/9 5/36-sqrt(15)/24; ...
%    5/36+sqrt(15)/30 2/9+sqrt(15)/15 5/36];
% b=[5/18 4/9 5/18];
% c=[1/2-sqrt(15)/10; 1/2; 1/2+sqrt(15)/10];
%%%%%%%%%%%%%%%% 4-stages %%%%%%%%%%%%%%%%
% w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
% w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
% w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
% w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
% A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
%    w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
%    w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
%    w1+w5 w11+w3+w44 w11+w3-w44 w1];
% b=[2*w1 2*w11 2*w11 2*w1];
% c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

tic;
nu=0.01;  rho=20;  N=128;  % thin  8*e-4
% nu=0.00005;  rho=100;  N=256;  % thick  3*e-4
T=0.5;  Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^2;
xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kx=1i*X_freq;  Ky=1i*Y_freq;  Kxx=(-1)*X_freq.^2;  Kyy=(-1)*Y_freq.^2;  Kxy=(-1)*X_freq.*Y_freq;  Kxxyy=Kxx+Kyy;  
Kxxyy_p=Kxxyy;  Kxxyy_p(1,1)=area; 
Kxxyy_f=spdiags(Kxxyy(:),0,N^2,N^2);  
L=nu*Kxxyy_f;  LL=[L sparse(N^2,N^2); sparse(N^2,N^2) L];

s=size(b,2);  Matrix1=(speye(s*2*N^2)-tau*kron(A,LL))^(-1);  Matrix2=tau*kron(A,speye(2*N^2));  Fmid=zeros(2*N^2,s);
matrix1=tau*kron(b,LL);  matrix2=tau*kron(b,speye(2*N^2));
 
fftcoe=1/N/N;  ifftcoe=N*N;
Y1=Y;  Y1((Y1>0.5))=0.25;  Y2=Y;  Y2((Y2<=0.5))=0.75; 
U1=tanh(rho*(Y1-0.25))+tanh(rho*(0.75-Y2));  U1_t=fftcoe*fft2(U1); 
delta=0.05;  U2=delta*sin(2*pi*X);  U2_t=fftcoe*fft2(U2);
U1_t_f=U1_t(:);  U2_t_f=U2_t(:);  U_t_f=[U1_t_f;U2_t_f];

for k=1:(T/tau)
    iter_err=1;  iter_count=1;  U_mid=kron(ones(s,1),U_t_f);  U_last=Matrix1*U_mid;
    while ( (iter_err>10^(-16)) && (iter_count<100) )
        for kk=1:s
            U1_mid_t_f=U_mid((kk-1)*2*N^2+1:(kk-1)*2*N^2+N^2);  U2_mid_t_f=U_mid((kk-1)*2*N^2+N^2+1:kk*2*N^2);
            U1_mid_t=reshape(U1_mid_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
            U2_mid_t=reshape(U2_mid_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
            G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
            G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
            F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  
            F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t; 
            Fmid(:,kk)=[F1_mid_t(:);F2_mid_t(:)];
        end
        U_mid_save=U_mid;
        U_mid=U_last+Matrix1*Matrix2*Fmid(:);
        iter_err=max(abs(U_mid_save-U_mid));
        iter_count=iter_count+1;
    end
    for kk=1:s
        U1_mid_t_f=U_mid((kk-1)*2*N^2+1:(kk-1)*2*N^2+N^2);  U2_mid_t_f=U_mid((kk-1)*2*N^2+N^2+1:kk*2*N^2);
        U1_mid_t=reshape(U1_mid_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
        U2_mid_t=reshape(U2_mid_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
        G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
        G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
        F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  
        F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t; 
        Fmid(:,kk)=[F1_mid_t(:);F2_mid_t(:)];
    end
    U_t_f=U_t_f+matrix1*U_mid+matrix2*Fmid(:);
    k
end

U_t_f1=U_t_f;
load U_4stage_Gauss_nu=0.01_rho=20_10000.mat
err=max(abs(U_t_f1-U_t_f));

time=toc;
