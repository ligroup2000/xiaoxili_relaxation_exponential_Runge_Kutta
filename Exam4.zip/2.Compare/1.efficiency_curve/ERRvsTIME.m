stepsize=[1/160 1/320 1/640 1/1280 1/2560];
Gauss_time=[];  Gauss_err=[];  ERK_time=[];  ERK_err=[];
for k=1:size(stepsize,2)
    tau=stepsize(k);
    % [ERKerr,ERKtime]=ERK22(tau);  [GAUSSerr,GAUSStime]=Gauss2(tau);
    [ERKerr,ERKtime]=ERK44(tau);  [GAUSSerr,GAUSStime]=Gauss4(tau);
    ERK_err=[ERK_err ERKerr];  ERK_time=[ERK_time ERKtime];
    Gauss_err=[Gauss_err GAUSSerr];  Gauss_time=[Gauss_time GAUSStime];
end