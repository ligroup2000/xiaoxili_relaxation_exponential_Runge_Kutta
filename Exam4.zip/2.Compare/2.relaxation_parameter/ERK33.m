function [err,time,GAMMA,tmesh]=ERK33(tau)
warning('off');
tic;
nu=0.01;  rho=20;  N=128;  % thin  8*e-4
T=2;  Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^2;
xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kx=1i*X_freq;  Ky=1i*Y_freq;  Kxx=(-1)*X_freq.^2;  Kyy=(-1)*Y_freq.^2;  Kxy=(-1)*X_freq.*Y_freq;  Kxxyy=Kxx+Kyy;  
Kxxyy_p=Kxxyy;  Kxxyy_p(1,1)=area; 
Kxxyy_f=spdiags(Kxxyy(:),0,N^2,N^2);
L=nu*Kxxyy_f;

c2=0.5;  c3=2/3;  
A21=c2*phipade(c2*tau*L,1);  
A32=(8/9)*phipade(c3*tau*L,2);  A31=c3*phipade(c3*tau*L,1)-A32;
b1=(1/4);  b3=(3/4);  
B3=(3/2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B3;
 
fftcoe=1/N/N;  ifftcoe=N*N;
Y1=Y;  Y1((Y1>0.5))=0.25;  Y2=Y;  Y2((Y2<=0.5))=0.75; 
U1=tanh(rho*(Y1-0.25))+tanh(rho*(0.75-Y2));  U1_t=fftcoe*fft2(U1); 
delta=0.05;  U2=delta*sin(2*pi*X);  U2_t=fftcoe*fft2(U2);
U1_t_f=U1_t(:);  U2_t_f=U2_t(:);  tn=0;  GAMMA=[];  tmesh=[];

while (tn<(T-tau))
    %%%% U1_n1_t_f  U2_n1_t_f
    LU1_t_f=L*U1_t_f;  LU2_t_f=L*U2_t_f;
    U1_n1_t_f=U1_t_f;  U2_n1_t_f=U2_t_f;
    %%%% U1_n2_t_f  U2_n2_t_f
    U1_mid_t=reshape(U1_n1_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
    U2_mid_t=reshape(U2_n1_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
    G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
    G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
    F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
    F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
    N1_n1_t_f=F1_mid_t_f+LU1_t_f;  N2_n1_t_f=F2_mid_t_f+LU2_t_f; 
    U1_n2_t_f=U1_t_f+tau*A21*N1_n1_t_f;  U2_n2_t_f=U2_t_f+tau*A21*N2_n1_t_f;
    %%%% U1_n3_t_f  U2_n3_t_f
    U1_mid_t=reshape(U1_n2_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
    U2_mid_t=reshape(U2_n2_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
    G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
    G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
    F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
    F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
    N1_n2_t_f=F1_mid_t_f+LU1_t_f;  N2_n2_t_f=F2_mid_t_f+LU2_t_f; 
    U1_n3_t_f=U1_t_f+tau*A31*N1_n1_t_f+tau*A32*N1_n2_t_f;  U2_n3_t_f=U2_t_f+tau*A31*N2_n1_t_f+tau*A32*N2_n2_t_f;
    %%%% U1_new_t_f  U2_new_t_f
    U1_mid_t=reshape(U1_n3_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
    U2_mid_t=reshape(U2_n3_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
    G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
    G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
    F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
    F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
    N1_n3_t_f=F1_mid_t_f+LU1_t_f;  N2_n3_t_f=F2_mid_t_f+LU2_t_f; 
    U1_new_t_f=U1_t_f+tau*B1*N1_n1_t_f+tau*B3*N1_n3_t_f;  U2_new_t_f=U2_t_f+tau*B1*N2_n1_t_f+tau*B3*N2_n3_t_f;   
    U1_Update_t_f=U1_new_t_f-U1_t_f;  U2_Update_t_f=U2_new_t_f-U2_t_f;  
    Update_norm=sum(abs(U1_Update_t_f))+sum(abs(U2_Update_t_f));
    if ( Update_norm==0 )
        gamma=1;
    else
        key=2*tau*b1*real(U1_n1_t_f'*L*U1_n1_t_f+U2_n1_t_f'*L*U2_n1_t_f) ...
           +2*tau*b3*real(U1_n3_t_f'*L*U1_n3_t_f+U2_n3_t_f'*L*U2_n3_t_f);
        gamma=(key-2*real(U1_t_f'*U1_Update_t_f)-2*real(U2_t_f'*U2_Update_t_f))/((U1_Update_t_f'*U1_Update_t_f)+(U2_Update_t_f'*U2_Update_t_f));
        fprintf('distance=%d, Update=%d',abs(gamma-1),Update_norm);
    end
    GAMMA=[GAMMA gamma];  tmesh=[tmesh tn];
    U1_t_f_save=U1_t_f;  U2_t_f_save=U2_t_f;  tn_save=tn;
    U1_t_f=U1_t_f+gamma*U1_Update_t_f;  U2_t_f=U2_t_f+gamma*U2_Update_t_f;  tn=tn+gamma*tau
end

if ( (T-tn)<=0 )
    GAMMA=GAMMA(1:end-1);  tmesh=tmesh(1:end-1); 
    U1_t_f=U1_t_f_save;  U2_t_f=U2_t_f_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
A21=c2*phipade(c2*tau*L,1);  
A32=(8/9)*phipade(c3*tau*L,2);  A31=c3*phipade(c3*tau*L,1)-A32;
B3=(3/2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B3;
%%%% U1_n1_t_f  U2_n1_t_f
LU1_t_f=L*U1_t_f;  LU2_t_f=L*U2_t_f;
U1_n1_t_f=U1_t_f;  U2_n1_t_f=U2_t_f;
%%%% U1_n2_t_f  U2_n2_t_f
U1_mid_t=reshape(U1_n1_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
U2_mid_t=reshape(U2_n1_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
N1_n1_t_f=F1_mid_t_f+LU1_t_f;  N2_n1_t_f=F2_mid_t_f+LU2_t_f; 
U1_n2_t_f=U1_t_f+tau*A21*N1_n1_t_f;  U2_n2_t_f=U2_t_f+tau*A21*N2_n1_t_f;
%%%% U1_n3_t_f  U2_n3_t_f
U1_mid_t=reshape(U1_n2_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
U2_mid_t=reshape(U2_n2_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
N1_n2_t_f=F1_mid_t_f+LU1_t_f;  N2_n2_t_f=F2_mid_t_f+LU2_t_f; 
U1_n3_t_f=U1_t_f+tau*A31*N1_n1_t_f+tau*A32*N1_n2_t_f;  U2_n3_t_f=U2_t_f+tau*A31*N2_n1_t_f+tau*A32*N2_n2_t_f;
%%%% U1_new_t_f  U2_new_t_f
U1_mid_t=reshape(U1_n3_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
U2_mid_t=reshape(U2_n3_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
N1_n3_t_f=F1_mid_t_f+LU1_t_f;  N2_n3_t_f=F2_mid_t_f+LU2_t_f; 
U1_t_f=U1_t_f+tau*B1*N1_n1_t_f+tau*B3*N1_n3_t_f;  U2_t_f=U2_t_f+tau*B1*N2_n1_t_f+tau*B3*N2_n3_t_f;  tn=tn+tau
GAMMA=[GAMMA 1];  tmesh=[tmesh tn];

load U_4stage_Gauss_nu=0.01_rho=20_10000.mat
err=max(abs(U_t_f-[U1_t_f;U2_t_f]));

time=toc;

