function [U1_save,U2_save,image_time,Divergence,tmesh,nu,rho,N]=ERK22(tau)
% nu=0.0001;  rho=30;  N=128;  % thin  8*e-4
nu=0.00005;  rho=100;  N=256;  % thick  3*e-4
T=10;  Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^2;
xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kx=1i*X_freq;  Ky=1i*Y_freq;  Kxx=(-1)*X_freq.^2;  Kyy=(-1)*Y_freq.^2;  Kxy=(-1)*X_freq.*Y_freq;  Kxxyy=Kxx+Kyy;  
Kxxyy_p=Kxxyy;  Kxxyy_p(1,1)=area; 
Kxxyy_f=spdiags(Kxxyy(:),0,N^2,N^2);
L=nu*Kxxyy_f;

c2=0.5;  A21=c2*phipade(c2*tau*L,1);  
b2=1;  B2=(1/c2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B2;
 
fftcoe=1/N/N;  ifftcoe=N*N;
Y1=Y;  Y1((Y1>0.5))=0.25;  Y2=Y;  Y2((Y2<=0.5))=0.75; 
U1=tanh(rho*(Y1-0.25))+tanh(rho*(0.75-Y2));  U1_t=fftcoe*fft2(U1); 
delta=0.05;  U2=delta*sin(2*pi*X);  U2_t=fftcoe*fft2(U2);
U1_t_f=U1_t(:);  U2_t_f=U2_t(:);  tn=0;  tmesh=[];  Divergence=[];
U1_save=U1_t_f;  U2_save=U2_t_f;  image_time=tn;

while (tn<(T-tau))
    %%%% U1_n1_t_f  U2_n1_t_f
    LU1_t_f=L*U1_t_f;  LU2_t_f=L*U2_t_f;
    U1_n1_t_f=U1_t_f;  U2_n1_t_f=U2_t_f;
    %%%% U1_n2_t_f  U2_n2_t_f
    U1_mid_t=reshape(U1_n1_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
    U2_mid_t=reshape(U2_n1_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
    G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
    G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
    F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
    F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
    N1_n1_t_f=F1_mid_t_f+LU1_t_f;  N2_n1_t_f=F2_mid_t_f+LU2_t_f; 
    U1_n2_t_f=U1_t_f+tau*A21*N1_n1_t_f;  U2_n2_t_f=U2_t_f+tau*A21*N2_n1_t_f;
    %%%% U1_new_t_f  U2_new_t_f
    U1_mid_t=reshape(U1_n2_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
    U2_mid_t=reshape(U2_n2_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
    G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
    G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
    F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
    F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
    N1_n2_t_f=F1_mid_t_f+LU1_t_f;  N2_n2_t_f=F2_mid_t_f+LU2_t_f; 
    U1_new_t_f=U1_t_f+tau*B1*N1_n1_t_f+tau*B2*N1_n2_t_f;  U2_new_t_f=U2_t_f+tau*B1*N2_n1_t_f+tau*B2*N2_n2_t_f;   
    U1_Update_t_f=U1_new_t_f-U1_t_f;  U2_Update_t_f=U2_new_t_f-U2_t_f;  
    tmesh=[tmesh tn];
    Divergence=[Divergence sqrt(sum(sum(abs(Kx.*reshape(U1_t_f,N,N)+Ky.*reshape(U2_t_f,N,N)).^2)))];
    Update_norm=sum(abs(U1_Update_t_f))+sum(abs(U2_Update_t_f));
    if ( Update_norm==0 )
        gamma=1;
    else
        key=2*tau*b2*real(U1_n2_t_f'*L*U1_n2_t_f+U2_n2_t_f'*L*U2_n2_t_f);
        gamma=(key-2*real(U1_t_f'*U1_Update_t_f)-2*real(U2_t_f'*U2_Update_t_f))/((U1_Update_t_f'*U1_Update_t_f)+(U2_Update_t_f'*U2_Update_t_f));
        fprintf('distance=%d, Update=%d',abs(gamma-1),Update_norm);
    end
    U1_t_f_save=U1_t_f;  U2_t_f_save=U2_t_f;  tn_save=tn;
    U1_t_f=U1_t_f+gamma*U1_Update_t_f;  U2_t_f=U2_t_f+gamma*U2_Update_t_f;  tn=tn+gamma*tau
    if ( (abs(tn-0.1)<tau) | (abs(tn-0.2)<tau) | (abs(tn-0.3)<tau) | (abs(tn-0.4)<tau) | (abs(tn-0.5)<tau) | (abs(tn-0.6)<tau) | (abs(tn-0.7)<tau) | (abs(tn-0.8)<tau) | (abs(tn-0.9)<tau) | (abs(tn-1)<tau) | (abs(tn-1.1)<tau)  )
        U1_save=[U1_save U1_t_f];  U2_save=[U2_save U2_t_f];  image_time=[image_time tn]; 
    end
end
Divergence=[Divergence sqrt(sum(sum(abs(Kx.*reshape(U1_t_f,N,N)+Ky.*reshape(U2_t_f,N,N)).^2)))];  tmesh=[tmesh tn];

if ( (T-tn)<=0 )
    Divergence=Divergence(1,1:end-1);  tmesh=tmesh(1,1:end-1);  
    U1_t_f=U1_t_f_save;  U2_t_f=U2_t_f_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
A21=c2*phipade(c2*tau*L,1);  
B2=(1/c2)*phipade(tau*L,2);  B1=phipade(tau*L,1)-B2;
%%%% U1_n1_t_f  U2_n1_t_f
LU1_t_f=L*U1_t_f;  LU2_t_f=L*U2_t_f;
U1_n1_t_f=U1_t_f;  U2_n1_t_f=U2_t_f;
%%%% U1_n2_t_f  U2_n2_t_f
U1_mid_t=reshape(U1_n1_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
U2_mid_t=reshape(U2_n1_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
N1_n1_t_f=F1_mid_t_f+LU1_t_f;  N2_n1_t_f=F2_mid_t_f+LU2_t_f; 
U1_n2_t_f=U1_t_f+tau*A21*N1_n1_t_f;  U2_n2_t_f=U2_t_f+tau*A21*N2_n1_t_f;
%%%% U1_new_t_f  U2_new_t_f
U1_mid_t=reshape(U1_n2_t_f,N,N);  U1_mid=real(ifftcoe*ifft2(U1_mid_t));  U1_mid_x=real(ifftcoe*ifft2(Kx.*U1_mid_t));  U1_mid_y=real(ifftcoe*ifft2(Ky.*U1_mid_t));
U2_mid_t=reshape(U2_n2_t_f,N,N);  U2_mid=real(ifftcoe*ifft2(U2_mid_t));  U2_mid_x=real(ifftcoe*ifft2(Kx.*U2_mid_t));  U2_mid_y=real(ifftcoe*ifft2(Ky.*U2_mid_t));
G1_mid_t=fftcoe*fft2(U1_mid.*U1_mid_x+U2_mid.*U1_mid_y);  G1_mid_t(1,1)=0;  G1_mid_t=G1_mid_t./Kxxyy_p; 
G2_mid_t=fftcoe*fft2(U1_mid.*U2_mid_x+U2_mid.*U2_mid_y);  G2_mid_t(1,1)=0;  G2_mid_t=G2_mid_t./Kxxyy_p;  
F1_mid_t=(-1)*Kyy.*G1_mid_t+Kxy.*G2_mid_t;  F1_mid_t_f=F1_mid_t(:);
F2_mid_t=(-1)*Kxx.*G2_mid_t+Kxy.*G1_mid_t;  F2_mid_t_f=F2_mid_t(:);
N1_n2_t_f=F1_mid_t_f+LU1_t_f;  N2_n2_t_f=F2_mid_t_f+LU2_t_f; 
U1_t_f=U1_t_f+tau*B1*N1_n1_t_f+tau*B2*N1_n2_t_f;  U2_t_f=U2_t_f+tau*B1*N2_n1_t_f+tau*B2*N2_n2_t_f;  tn=tn+tau

U1_save=[U1_save U1_t_f];  U2_save=[U2_save U2_t_f];  image_time=[image_time tn];

