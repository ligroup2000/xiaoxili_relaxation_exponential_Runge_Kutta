%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 2;     % ��ͼ����
TightPlot.RowNumber = 4;    % ��ͼ����
TightPlot.GapW = 0.025;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.04;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.01;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.02;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.02;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

load ERK22-thick-700.mat
axes(p(1));    % ��ȡ��ǰfigure����Ϣ
Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^3;  ifftcoe=N^2;
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
xmesh=Le:h:Re;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh); 
Kx=1i*X_freq;  Ky=1i*Y_freq;
W=real(ifftcoe*ifft2(Kx.*reshape(U2_save(:,1),N,N)))-real(ifftcoe*ifft2(Ky.*reshape(U1_save(:,1),N,N))); 
WW=zeros(N+1,N+1);
WW(1:N,1:N)=W;   
WW(1:N,1+N)=WW(1:N,1);  
WW(1+N,1:N+1)=WW(1,1:N+1);  
WW(N+1,N+1)=WW(1,1);
contour(X,Y,WW,'Levelstep',1,'Fill','on');
set(gca,'XLim',[0,1])
set(gca,'YLim',[0,1])
set(gca,'xtick',[],'ytick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
box on;  
brighten(0);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(2));    % ��ȡ��ǰfigure����Ϣ
Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^3;  ifftcoe=N^2;
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
xmesh=Le:h:Re;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh); 
Kx=1i*X_freq;  Ky=1i*Y_freq;
W=real(ifftcoe*ifft2(Kx.*reshape(U2_save(:,11),N,N)))-real(ifftcoe*ifft2(Ky.*reshape(U1_save(:,11),N,N))); 
WW=zeros(N+1,N+1);
WW(1:N,1:N)=W;   
WW(1:N,1+N)=WW(1:N,1);  
WW(1+N,1:N+1)=WW(1,1:N+1);  
WW(N+1,N+1)=WW(1,1);
contour(X,Y,WW,'Levelstep',1,'Fill','on');
set(gca,'XLim',[0,1])
set(gca,'YLim',[0,1])
set(gca,'xtick',[],'ytick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
box on;  
brighten(0);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(3));    % ��ȡ��ǰfigure����Ϣ
Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^3;  ifftcoe=N^2;
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
xmesh=Le:h:Re;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh); 
Kx=1i*X_freq;  Ky=1i*Y_freq;
W=real(ifftcoe*ifft2(Kx.*reshape(U2_save(:,14),N,N)))-real(ifftcoe*ifft2(Ky.*reshape(U1_save(:,14),N,N))); 
WW=zeros(N+1,N+1);
WW(1:N,1:N)=W;   
WW(1:N,1+N)=WW(1:N,1);  
WW(1+N,1:N+1)=WW(1,1:N+1);  
WW(N+1,N+1)=WW(1,1);
contour(X,Y,WW,'Levelstep',1,'Fill','on');
set(gca,'XLim',[0,1])
set(gca,'YLim',[0,1])
set(gca,'xtick',[],'ytick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
box on;  
brighten(0);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(4));    % ��ȡ��ǰfigure����Ϣ
Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^3;  ifftcoe=N^2;
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
xmesh=Le:h:Re;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh); 
Kx=1i*X_freq;  Ky=1i*Y_freq;
W=real(ifftcoe*ifft2(Kx.*reshape(U2_save(:,24),N,N)))-real(ifftcoe*ifft2(Ky.*reshape(U1_save(:,24),N,N))); 
WW=zeros(N+1,N+1);
WW(1:N,1:N)=W;   
WW(1:N,1+N)=WW(1:N,1);  
WW(1+N,1:N+1)=WW(1,1:N+1);  
WW(N+1,N+1)=WW(1,1);
contour(X,Y,WW,'Levelstep',1,'Fill','on');
set(gca,'XLim',[0,1])
set(gca,'YLim',[0,1])
set(gca,'xtick',[],'ytick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
box on;  
brighten(0);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

load ERK22-thin-2000.mat
axes(p(5));    % ��ȡ��ǰfigure����Ϣ
Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^3;  ifftcoe=N^2;
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
xmesh=Le:h:Re;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh); 
Kx=1i*X_freq;  Ky=1i*Y_freq;
W=real(ifftcoe*ifft2(Kx.*reshape(U2_save(:,1),N,N)))-real(ifftcoe*ifft2(Ky.*reshape(U1_save(:,1),N,N))); 
WW=zeros(N+1,N+1);
WW(1:N,1:N)=W;   
WW(1:N,1+N)=WW(1:N,1);  
WW(1+N,1:N+1)=WW(1,1:N+1);  
WW(N+1,N+1)=WW(1,1);
contour(X,Y,WW,'Levelstep',1,'Fill','on');
set(gca,'XLim',[0,1])
set(gca,'YLim',[0,1])
set(gca,'xtick',[],'ytick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
box on;  
brighten(0);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(6));    % ��ȡ��ǰfigure����Ϣ
Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^3;  ifftcoe=N^2;
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
xmesh=Le:h:Re;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh); 
Kx=1i*X_freq;  Ky=1i*Y_freq;
W=real(ifftcoe*ifft2(Kx.*reshape(U2_save(:,10),N,N)))-real(ifftcoe*ifft2(Ky.*reshape(U1_save(:,10),N,N))); 
WW=zeros(N+1,N+1);
WW(1:N,1:N)=W;   
WW(1:N,1+N)=WW(1:N,1);  
WW(1+N,1:N+1)=WW(1,1:N+1);  
WW(N+1,N+1)=WW(1,1);
contour(X,Y,WW,'Levelstep',1,'Fill','on');
set(gca,'XLim',[0,1])
set(gca,'YLim',[0,1])
set(gca,'xtick',[],'ytick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
box on;  
brighten(0);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(7));    % ��ȡ��ǰfigure����Ϣ
Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^3;  ifftcoe=N^2;
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
xmesh=Le:h:Re;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh); 
Kx=1i*X_freq;  Ky=1i*Y_freq;
W=real(ifftcoe*ifft2(Kx.*reshape(U2_save(:,15),N,N)))-real(ifftcoe*ifft2(Ky.*reshape(U1_save(:,15),N,N))); 
WW=zeros(N+1,N+1);
WW(1:N,1:N)=W;   
WW(1:N,1+N)=WW(1:N,1);  
WW(1+N,1:N+1)=WW(1,1:N+1);  
WW(N+1,N+1)=WW(1,1);
contour(X,Y,WW,'Levelstep',1,'Fill','on');
set(gca,'XLim',[0,1])
set(gca,'YLim',[0,1])
set(gca,'xtick',[],'ytick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
box on;  
brighten(0);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ

axes(p(8));    % ��ȡ��ǰfigure����Ϣ
Le=0;  Re=1;  h=(Re-Le)/N;  area=(Re-Le)^3;  ifftcoe=N^2;
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
xmesh=Le:h:Re;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh); 
Kx=1i*X_freq;  Ky=1i*Y_freq;
W=real(ifftcoe*ifft2(Kx.*reshape(U2_save(:,24),N,N)))-real(ifftcoe*ifft2(Ky.*reshape(U1_save(:,24),N,N))); 
WW=zeros(N+1,N+1);
WW(1:N,1:N)=W;   
WW(1:N,1+N)=WW(1:N,1);  
WW(1+N,1:N+1)=WW(1,1:N+1);  
WW(N+1,N+1)=WW(1,1);
contour(X,Y,WW,'Levelstep',1,'Fill','on');
set(gca,'XLim',[0,1])
set(gca,'YLim',[0,1])
set(gca,'xtick',[],'ytick',[])
xlabel('$x$','interpreter','latex','FontSize',20)
ylabel('$y$','interpreter','latex','FontSize',20)
box on;  
brighten(0);       %����
camlight right;      %��Դλ��
lighting phong;      %����ģʽ